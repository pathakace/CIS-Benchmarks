#Requires -RunAsAdministrator
<#
.SYNOPSIS
    CIS Level 1 Windows Server 2022 - P3 Lower Priority Controls
    Environment-Specific / Defense-in-Depth (40 controls)

.DESCRIPTION
    Applies P3 CIS Level 1 controls. These are environment-specific, workstation-focused,
    or provide defense-in-depth. Apply via GPO/Intune as needed.
    Review each section for applicability to your environment before applying.

.NOTES
    Author      : Enterprise Windows Architecture Team
    Version     : 1.0
    CIS Ref     : CIS Microsoft Windows Server 2022 Benchmark
    Priority    : P3 - Lower (Environment-Specific, as needed)
    Run As      : Local Administrator or SYSTEM

.EXAMPLE
    .\CIS_P3_Lower_Priority_Controls.ps1
    .\CIS_P3_Lower_Priority_Controls.ps1 -WhatIf
    .\CIS_P3_Lower_Priority_Controls.ps1 -SkipWorkstationControls
    .\CIS_P3_Lower_Priority_Controls.ps1 -LogPath "C:\Logs\CIS_P3.log"
#>

[CmdletBinding(SupportsShouldProcess)]
param(
    [string]$LogPath                = "C:\Windows\Logs\CIS_P3_Remediation_$(Get-Date -Format 'yyyyMMdd_HHmmss').log",
    [switch]$SkipWorkstationControls,   # Skip controls that only apply to workstations
    [switch]$SkipPrivacyTelemetry,      # Skip privacy/telemetry controls
    [switch]$SkipPrinterControls        # Skip printer security controls
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

#region --- Helpers ---
function Write-Log {
    param([string]$Message, [ValidateSet('INFO','WARN','ERROR','OK','SKIP')]$Level = 'INFO')
    $ts = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    $entry = "[$ts][$Level] $Message"
    $color = switch($Level) { 'OK'{'Green'} 'WARN'{'Yellow'} 'ERROR'{'Red'} 'SKIP'{'DarkGray'} default{'Cyan'} }
    Write-Host $entry -ForegroundColor $color
    Add-Content -Path $LogPath -Value $entry -ErrorAction SilentlyContinue
}

function Set-RegistryValue {
    param(
        [string]$Path, [string]$Name, $Value,
        [string]$Type = 'DWord', [string]$CISRef, [string]$Description,
        [switch]$WorkstationOnly, [switch]$PrivacyRelated, [switch]$PrinterRelated
    )
    if ($WorkstationOnly -and $SkipWorkstationControls) {
        Write-Log "[$CISRef] SKIP - $Description (workstation control skipped)" -Level SKIP; return
    }
    if ($PrivacyRelated -and $SkipPrivacyTelemetry) {
        Write-Log "[$CISRef] SKIP - $Description (privacy/telemetry control skipped)" -Level SKIP; return
    }
    if ($PrinterRelated -and $SkipPrinterControls) {
        Write-Log "[$CISRef] SKIP - $Description (printer control skipped)" -Level SKIP; return
    }
    try {
        if (-not (Test-Path $Path)) { New-Item -Path $Path -Force | Out-Null }
        if ($PSCmdlet.ShouldProcess("$Path\$Name", "Set to '$Value'")) {
            Set-ItemProperty -Path $Path -Name $Name -Value $Value -Type $Type -Force
            Write-Log "[$CISRef] OK - $Description" -Level OK
        }
    } catch { Write-Log "[$CISRef] FAILED - $Description : $_" -Level ERROR }
}
#endregion

Write-Log "===== CIS P3 Lower Priority Controls - START =====" -Level INFO
Write-Log "Host: $env:COMPUTERNAME | OS: $((Get-WmiObject Win32_OperatingSystem).Caption)" -Level INFO
Write-Log "Options: SkipWorkstation=$SkipWorkstationControls, SkipPrivacy=$SkipPrivacyTelemetry, SkipPrinter=$SkipPrinterControls" -Level INFO

# ─────────────────────────────────────────────────────────────
# SECTION 2.3: SECURITY OPTIONS
# ─────────────────────────────────────────────────────────────
Write-Log "--- Section 2.3: Security Options ---" -Level INFO

# 2.3.2.2 Audit: Shut down system immediately if unable to log security audits
Set-RegistryValue `
    -Path  'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa' `
    -Name  'CrashOnAuditFail' `
    -Value 0 -Type DWord `
    -CISRef '2.3.2.2' `
    -Description 'Shut down system if unable to log audits = Disabled (set to 0 for servers; use 1 for high-security)'

# NOTE: 2.3.7.4 and 2.3.7.5 (Legal Notice) are handled in P2. Included here as reminder only.
Write-Log "[2.3.7.4/2.3.7.5] INFO - Legal notice text/title applied in P2 script" -Level INFO

# ─────────────────────────────────────────────────────────────
# SECTION 18.1: WORKSTATION UI
# ─────────────────────────────────────────────────────────────
Write-Log "--- Section 18.1: Workstation UI Controls ---" -Level INFO

# 18.1.1.1 Prevent enabling lock screen camera
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Personalization' `
    -Name  'NoLockScreenCamera' `
    -Value 1 -Type DWord `
    -CISRef '18.1.1.1' -Description 'Prevent lock screen camera' `
    -WorkstationOnly

# 18.1.1.2 Prevent enabling lock screen slide show
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Personalization' `
    -Name  'NoLockScreenSlideshow' `
    -Value 1 -Type DWord `
    -CISRef '18.1.1.2' -Description 'Prevent lock screen slide show' `
    -WorkstationOnly

# 18.1.2.2 Turn off online speech recognition
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft\InputPersonalization' `
    -Name  'AllowInputPersonalization' `
    -Value 0 -Type DWord `
    -CISRef '18.1.2.2' -Description 'Turn off online speech recognition' `
    -PrivacyRelated

# ─────────────────────────────────────────────────────────────
# SECTION 18.4: NETWORK / EXPLOIT MITIGATION
# ─────────────────────────────────────────────────────────────
Write-Log "--- Section 18.4/18.5: Network and MSS Settings ---" -Level INFO

# 18.4.5 MSS: Enable Structured Exception Handler Overwrite Protection (SEHOP)
Set-RegistryValue `
    -Path  'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\kernel' `
    -Name  'DisableExceptionChainValidation' `
    -Value 0 -Type DWord `
    -CISRef '18.4.5' -Description 'Enable SEHOP (Structured Exception Handler Overwrite Protection)'

# 18.4.6 MSS: Configure NetBT NodeType = P-node (no broadcasts)
Set-RegistryValue `
    -Path  'HKLM:\SYSTEM\CurrentControlSet\Services\NetBT\Parameters' `
    -Name  'NodeType' `
    -Value 2 -Type DWord `
    -CISRef '18.4.6' -Description 'NetBT NodeType = P-node (2) to avoid broadcast name resolution'

# 18.5.2 MSS: Disable IPv6 source routing
Set-RegistryValue `
    -Path  'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip6\Parameters' `
    -Name  'DisableIPSourceRouting' `
    -Value 2 -Type DWord `
    -CISRef '18.5.2' -Description 'Disable IPv6 source routing'

# 18.5.3 MSS: Disable IPv4 source routing
Set-RegistryValue `
    -Path  'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters' `
    -Name  'DisableIPSourceRouting' `
    -Value 2 -Type DWord `
    -CISRef '18.5.3' -Description 'Disable IPv4 source routing'

# 18.5.4 MSS: Disable ICMP redirects
Set-RegistryValue `
    -Path  'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters' `
    -Name  'EnableICMPRedirect' `
    -Value 0 -Type DWord `
    -CISRef '18.5.4' -Description 'Disable ICMP redirects'

# 18.5.6 MSS: Allow NBNS to release name on WINS conflict = Disabled
Set-RegistryValue `
    -Path  'HKLM:\SYSTEM\CurrentControlSet\Services\NetBT\Parameters' `
    -Name  'NoNameReleaseOnDemand' `
    -Value 1 -Type DWord `
    -CISRef '18.5.6' -Description 'Prevent NetBIOS name release on WINS server conflict'

# 18.5.9 MSS: Screen saver grace period
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon' `
    -Name  'ScreenSaverGracePeriod' `
    -Value '5' -Type String `
    -CISRef '18.5.9' -Description 'Screen saver grace period = 5 seconds'

# 18.5.12 MSS: Security event log warning threshold = 90%
Set-RegistryValue `
    -Path  'HKLM:\SYSTEM\CurrentControlSet\Services\Eventlog\Security' `
    -Name  'WarningLevel' `
    -Value 90 -Type DWord `
    -CISRef '18.5.12' -Description 'Security event log warning threshold = 90%'

# ─────────────────────────────────────────────────────────────
# SECTION 18.6: NETWORK CONFIGURATION
# ─────────────────────────────────────────────────────────────
Write-Log "--- Section 18.6: Network Configuration ---" -Level INFO

# 18.6.4.2 Configure NetBIOS settings
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\DNSClient' `
    -Name  'EnableNetbios' `
    -Value 0 -Type DWord `
    -CISRef '18.6.4.2' -Description 'Disable NetBIOS via DNS client policy'

# 18.6.4.3 Disable multicast name resolution (LLMNR)
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\DNSClient' `
    -Name  'EnableMulticast' `
    -Value 0 -Type DWord `
    -CISRef '18.6.4.3' -Description 'Disable LLMNR (multicast name resolution)'

# 18.6.11.2 Prohibit installation and configuration of Network Bridge
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Network Connections' `
    -Name  'NC_AllowNetBridge_NLA' `
    -Value 0 -Type DWord `
    -CISRef '18.6.11.2' -Description 'Prohibit Network Bridge installation'

# 18.6.11.3 Disable Internet Connection Sharing
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Network Connections' `
    -Name  'NC_ShowSharedAccessUI' `
    -Value 0 -Type DWord `
    -CISRef '18.6.11.3' -Description 'Disable Internet Connection Sharing'

# 18.6.11.4 Require elevation for network location change
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Network Connections' `
    -Name  'NC_StdDomainUserSetLocation' `
    -Value 1 -Type DWord `
    -CISRef '18.6.11.4' -Description 'Require elevation to change network location'

# 18.6.14.1 Hardened UNC Paths (\\*\SYSVOL and \\*\NETLOGON)
try {
    if ($PSCmdlet.ShouldProcess("UNC Hardened Paths", "Configure for SYSVOL and NETLOGON")) {
        $uncPath = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\NetworkProvider\HardenedPaths'
        if (-not (Test-Path $uncPath)) { New-Item -Path $uncPath -Force | Out-Null }
        Set-ItemProperty -Path $uncPath -Name '\\*\SYSVOL'  -Value 'RequireMutualAuthentication=1,RequireIntegrity=1' -Type String -Force
        Set-ItemProperty -Path $uncPath -Name '\\*\NETLOGON' -Value 'RequireMutualAuthentication=1,RequireIntegrity=1' -Type String -Force
        Write-Log "[18.6.14.1] OK - Hardened UNC paths configured for SYSVOL and NETLOGON" -Level OK
    }
} catch { Write-Log "[18.6.14.1] FAILED - Hardened UNC paths: $_" -Level ERROR }

# 18.6.21.1 Minimize simultaneous connections to Internet/domain
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WcmSvc\GroupPolicy' `
    -Name  'fMinimizeConnections' `
    -Value 3 -Type DWord `
    -CISRef '18.6.21.1' -Description 'Minimize simultaneous network connections'

# ─────────────────────────────────────────────────────────────
# SECTION 18.7: PRINTER SECURITY
# ─────────────────────────────────────────────────────────────
Write-Log "--- Section 18.7: Printer Security ---" -Level INFO

# 18.7.2 Redirection Guard
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Printers' `
    -Name  'RedirectionGuardPolicy' `
    -Value 1 -Type DWord `
    -CISRef '18.7.2' -Description 'Enable Redirection Guard' `
    -PrinterRelated

# 18.7.3-7 RPC connection settings for printing
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Printers\RPC' `
    -Name  'RpcUseNamedPipeProtocol' `
    -Value 0 -Type DWord `
    -CISRef '18.7.3' -Description 'Configure RPC over TCP for printing' `
    -PrinterRelated

Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Printers\RPC' `
    -Name  'RpcAuthentication' `
    -Value 0 -Type DWord `
    -CISRef '18.7.4' -Description 'Configure RPC connection authentication' `
    -PrinterRelated

Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Printers\RPC' `
    -Name  'RpcProtocols' `
    -Value 5 -Type DWord `
    -CISRef '18.7.5' -Description 'Configure RPC connection protocols' `
    -PrinterRelated

Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Printers\RPC' `
    -Name  'ForceKerberosForRpc' `
    -Value 0 -Type DWord `
    -CISRef '18.7.6' -Description 'Configure RPC listener protocols' `
    -PrinterRelated

Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Printers\RPC' `
    -Name  'RpcTcpPort' `
    -Value 0 -Type DWord `
    -CISRef '18.7.7' -Description 'Configure RPC over TCP port' `
    -PrinterRelated

# 18.7.8-11 Print driver restrictions
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Printers' `
    -Name  'RestrictDriverInstallationToAdministrators' `
    -Value 1 -Type DWord `
    -CISRef '18.7.8' -Description 'Restrict printer driver install to Administrators' `
    -PrinterRelated

Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Printers\PackagePointAndPrint' `
    -Name  'PackagePointAndPrintOnly' `
    -Value 1 -Type DWord `
    -CISRef '18.7.9' -Description 'Limits print driver installation to approved servers' `
    -PrinterRelated

Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Printers\PackagePointAndPrint' `
    -Name  'PackagePointAndPrintServerList' `
    -Value 1 -Type DWord `
    -CISRef '18.7.10' -Description 'Package Point and Print: Use approved servers only' `
    -PrinterRelated

Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Printers\PointAndPrint' `
    -Name  'NoWarningNoElevationOnInstall' `
    -Value 0 -Type DWord `
    -CISRef '18.7.11' -Description 'Point and Print: Warn and elevate on driver install' `
    -PrinterRelated

# ─────────────────────────────────────────────────────────────
# SECTION 18.9: SYSTEM / DRIVER / BOOT
# ─────────────────────────────────────────────────────────────
Write-Log "--- Section 18.9: System / Boot / Driver Settings ---" -Level INFO

# 18.9.3.1 Include command line in process creation events
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System\Audit' `
    -Name  'ProcessCreationIncludeCmdLine_Enabled' `
    -Value 1 -Type DWord `
    -CISRef '18.9.3.1' -Description 'Include command line data in process creation audit events'

# 18.9.4.1 Encryption Oracle Remediation = Force Updated Clients
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System\CredSSP\Parameters' `
    -Name  'AllowEncryptionOracle' `
    -Value 0 -Type DWord `
    -CISRef '18.9.4.1' -Description 'CredSSP: Encryption Oracle Remediation = Force Updated Clients'

# 18.9.4.2 Remote host delegation of non-exportable credentials = Enabled
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation' `
    -Name  'AllowProtectedCreds' `
    -Value 1 -Type DWord `
    -CISRef '18.9.4.2' -Description 'Enable Remote Credential Guard (non-exportable credentials)'

# 18.9.7.2 Prevent retrieval of device metadata from Internet
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Device Metadata' `
    -Name  'PreventDeviceMetadataFromNetwork' `
    -Value 1 -Type DWord `
    -CISRef '18.9.7.2' -Description 'Prevent device metadata retrieval from Internet' `
    -PrivacyRelated

# 18.9.13.1 Boot-Start Driver Initialization Policy = Good and unknown
Set-RegistryValue `
    -Path  'HKLM:\SYSTEM\CurrentControlSet\Policies\EarlyLaunch' `
    -Name  'DriverLoadPolicy' `
    -Value 3 -Type DWord `
    -CISRef '18.9.13.1' -Description 'Boot-Start Driver Init = Good, unknown, unknown but critical'

# 18.9.19.2-5 Registry / Group Policy processing
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Group Policy\{35378EAC-683F-11D2-A89A-00C04FBBCFA2}' `
    -Name  'NoGPOListChanges' `
    -Value 0 -Type DWord `
    -CISRef '18.9.19.2' -Description 'Always process registry GPO even unchanged'

Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Group Policy\{827D319E-6EAC-11D2-A4EA-00C04F79F83A}' `
    -Name  'NoGPOListChanges' `
    -Value 0 -Type DWord `
    -CISRef '18.9.19.3' -Description 'Always process security GPO even unchanged'

Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Group Policy\{B1BE8D72-6EAC-11D2-A4EA-00C04F79F83A}' `
    -Name  'NoGPOListChanges' `
    -Value 0 -Type DWord `
    -CISRef '18.9.19.4' -Description 'Always process IP security GPO even unchanged'

Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Group Policy\{3610EDA5-77EF-11D2-8DC5-00C04FA31A66}' `
    -Name  'NoGPOListChanges' `
    -Value 0 -Type DWord `
    -CISRef '18.9.19.5' -Description 'Always process wireless GPO even unchanged'

# 18.9.24.1 Kernel DMA Protection
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Kernel DMA Protection' `
    -Name  'DeviceEnumerationPolicy' `
    -Value 0 -Type DWord `
    -CISRef '18.9.24.1' -Description 'Kernel DMA Protection: Block all external DMA-capable devices'

# 18.9.25.1 LSA: Prevent custom SSPs/APs from loading (Credential Guard support)
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft\Windows\System' `
    -Name  'RunAsPPL' `
    -Value 1 -Type DWord `
    -CISRef '18.9.25.1' -Description 'Configure LSASS to run as protected process (PPL)'

# ─────────────────────────────────────────────────────────────
# SECTION 18.9.27: SIGN-IN UI SETTINGS
# ─────────────────────────────────────────────────────────────
Write-Log "--- Section 18.9.27: Sign-In UI Settings ---" -Level INFO

Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' `
    -Name  'BlockDomainPicturePassword' `
    -Value 1 -Type DWord `
    -CISRef '18.9.27.1' -Description 'Disable picture password sign-in' `
    -WorkstationOnly

Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft\Windows\System' `
    -Name  'DontDisplayNetworkSelectionUI' `
    -Value 1 -Type DWord `
    -CISRef '18.9.27.2' -Description 'Do not display network selection UI on logon screen' `
    -WorkstationOnly

Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft\Windows\System' `
    -Name  'DisableLockScreenAppNotifications' `
    -Value 1 -Type DWord `
    -CISRef '18.9.27.3' -Description 'Disable app notifications on lock screen' `
    -WorkstationOnly

# ─────────────────────────────────────────────────────────────
# SECTION 18.9.34 / 18.9.35: REMOTE ASSISTANCE AND RPC
# ─────────────────────────────────────────────────────────────
Write-Log "--- Section 18.9.34/35: Remote Assistance and RPC ---" -Level INFO

# 18.9.34.1 Configure offer Remote Assistance = Disabled
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services' `
    -Name  'fAllowUnsolicited' `
    -Value 0 -Type DWord `
    -CISRef '18.9.34.1' -Description 'Disable unsolicited (offer) Remote Assistance'

# 18.9.34.2 Configure solicited Remote Assistance = Disabled
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services' `
    -Name  'fAllowToGetHelp' `
    -Value 0 -Type DWord `
    -CISRef '18.9.34.2' -Description 'Disable solicited Remote Assistance'

# 18.9.35.1 RPC Endpoint Mapper Client Authentication = Enabled
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Rpc' `
    -Name  'EnableAuthEpResolution' `
    -Value 1 -Type DWord `
    -CISRef '18.9.35.1' -Description 'RPC Endpoint Mapper: Require authentication'

# ─────────────────────────────────────────────────────────────
# SECTION 18.10: APPLICATION CONTROLS AND PRIVACY
# ─────────────────────────────────────────────────────────────
Write-Log "--- Section 18.10: Application Controls and Privacy ---" -Level INFO

# 18.10.5.1 Accounts: Microsoft accounts = optional
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' `
    -Name  'NoConnectedUser' `
    -Value 3 -Type DWord `
    -CISRef '18.10.5.1' -Description 'Microsoft accounts: Users cannot add or log on with Microsoft accounts'

# 18.10.7.1 Autoplay for non-volume devices = Disabled
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Explorer' `
    -Name  'NoAutoplayfornonVolume' `
    -Value 1 -Type DWord `
    -CISRef '18.10.7.1' -Description 'Disable Autoplay for non-volume devices (cameras, phones)'

# 18.10.8.1.1 Enhanced anti-spoofing
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft\Biometrics\FacialFeatures' `
    -Name  'EnhancedAntiSpoofing' `
    -Value 1 -Type DWord `
    -CISRef '18.10.8.1.1' -Description 'Enable enhanced anti-spoofing for facial recognition' `
    -WorkstationOnly

# 18.10.12.1 Disable Windows consumer experiences
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft\Windows\CloudContent' `
    -Name  'DisableWindowsConsumerFeatures' `
    -Value 1 -Type DWord `
    -CISRef '18.10.12.1' -Description 'Disable Windows consumer experiences' `
    -PrivacyRelated

# 18.10.13.1 Disable PIN for pairing
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Connect' `
    -Name  'RequirePinForPairing' `
    -Value 1 -Type DWord `
    -CISRef '18.10.13.1' -Description 'Require PIN for wireless projection pairing'

# 18.10.15.1 Diagnostic data level = 1 (Required)
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DataCollection' `
    -Name  'AllowTelemetry' `
    -Value 1 -Type DWord `
    -CISRef '18.10.15.1' -Description 'Configure diagnostic data = Required (basic) only' `
    -PrivacyRelated

# 18.10.17.1-4 App Installer controls
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft\Windows\AppInstaller' `
    -Name  'EnableAppInstaller' `
    -Value 0 -Type DWord `
    -CISRef '18.10.17.1' -Description 'Disable App Installer (winget) via policy'

Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft\Windows\AppInstaller' `
    -Name  'EnableMSAppInstallerProtocol' `
    -Value 0 -Type DWord `
    -CISRef '18.10.17.2' -Description 'Disable ms-appinstaller protocol'

Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft\Windows\AppInstaller' `
    -Name  'EnableExperimentalFeatures' `
    -Value 0 -Type DWord `
    -CISRef '18.10.17.3' -Description 'Disable App Installer experimental features'

Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft\Windows\AppInstaller' `
    -Name  'EnableHashOverride' `
    -Value 0 -Type DWord `
    -CISRef '18.10.17.4' -Description 'Disable App Installer hash override'

# 18.10.26.x Event log sizes
$logSizes = @{
    'Application' = 32768
    'Security'    = 196608
    'Setup'       = 32768
    'System'      = 32768
}
foreach ($log in $logSizes.GetEnumerator()) {
    try {
        if ($PSCmdlet.ShouldProcess("$($log.Key) event log", "Set max size to $($log.Value) KB")) {
            $regPath = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\EventLog\$($log.Key)"
            if (-not (Test-Path $regPath)) { New-Item -Path $regPath -Force | Out-Null }
            Set-ItemProperty -Path $regPath -Name 'MaxSize' -Value $log.Value -Type DWord -Force
            Write-Log "[18.10.26] OK - $($log.Key) log max size = $($log.Value) KB" -Level OK
        }
    } catch { Write-Log "[18.10.26] FAILED - $($log.Key) log size: $_" -Level ERROR }
}

# 18.10.29.2-4 Explorer security
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer' `
    -Name  'PreXPSP2ShellProtocolBehavior' `
    -Value 0 -Type DWord `
    -CISRef '18.10.29.2' -Description 'Disable pre-XP SP2 shell protocol behavior'

Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Explorer' `
    -Name  'NoDataExecutionPrevention' `
    -Value 0 -Type DWord `
    -CISRef '18.10.29.3' -Description 'Enable Data Execution Prevention for Explorer'

Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Explorer' `
    -Name  'NoHeapTerminationOnCorruption' `
    -Value 0 -Type DWord `
    -CISRef '18.10.29.4' -Description 'Enable heap termination on corruption'

# 18.10.42.1 Block consumer Microsoft account authentication
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft\MicrosoftAccount' `
    -Name  'DisableUserAuth' `
    -Value 1 -Type DWord `
    -CISRef '18.10.42.1' -Description 'Block consumer Microsoft account authentication'

# 18.10.51.1 Prevent OneDrive for Business file storage
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft\Windows\OneDrive' `
    -Name  'DisableFileSyncNGSC' `
    -Value 1 -Type DWord `
    -CISRef '18.10.51.1' -Description 'Disable OneDrive personal file storage' `
    -PrivacyRelated

# 18.10.57.2.2 Do not allow passwords to be saved (RDP)
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services' `
    -Name  'DisablePasswordSaving' `
    -Value 1 -Type DWord `
    -CISRef '18.10.57.2.2' -Description 'RDP: Do not allow passwords to be saved'

# 18.10.57.3.3.3 Disable drive redirection in RDP
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services' `
    -Name  'fDisableCdm' `
    -Value 1 -Type DWord `
    -CISRef '18.10.57.3.3.3' -Description 'RDP: Disable client drive redirection'

# 18.10.57.3.9.1 Set RDP automatic reconnection attempts
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services' `
    -Name  'MaxConnectionTime' `
    -Value 28800000 -Type DWord `
    -CISRef '18.10.57.3.9.1' -Description 'RDP: Maximum connection time = 8 hours'

Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services' `
    -Name  'MaxIdleTime' `
    -Value 900000 -Type DWord `
    -CISRef '18.10.57.3.9.2' -Description 'RDP: Maximum idle time = 15 minutes'

Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services' `
    -Name  'MaxDisconnectionTime' `
    -Value 60000 -Type DWord `
    -CISRef '18.10.57.3.9.3' -Description 'RDP: Disconnected session end time = 1 minute'

# 18.10.57.3.11.1-2 RDP temp folder settings
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services' `
    -Name  'DeleteTempDirsOnExit' `
    -Value 1 -Type DWord `
    -CISRef '18.10.57.3.11.1' -Description 'RDP: Delete temp folders on exit'

Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services' `
    -Name  'PerSessionTempDir' `
    -Value 1 -Type DWord `
    -CISRef '18.10.57.3.11.2' -Description 'RDP: Use per-session temp folders'

# 18.10.76.2.1 Windows Defender SmartScreen
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft\Windows\System' `
    -Name  'EnableSmartScreen' `
    -Value 1 -Type DWord `
    -CISRef '18.10.76.2.1' -Description 'Enable Windows Defender SmartScreen'

Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft\Windows\System' `
    -Name  'ShellSmartScreenLevel' `
    -Value 'Block' -Type String `
    -CISRef '18.10.76.2.1' -Description 'SmartScreen level = Block'

# 18.10.81.1 User control over MSI installs = Disabled
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Installer' `
    -Name  'EnableUserControl' `
    -Value 0 -Type DWord `
    -CISRef '18.10.81.1' -Description 'Disable user control over MSI install options'

# 18.10.87.2 PowerShell Transcription
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft\Windows\PowerShell\Transcription' `
    -Name  'EnableTranscripting' `
    -Value 1 -Type DWord `
    -CISRef '18.10.87.2' -Description 'Enable PowerShell Transcription'

Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft\Windows\PowerShell\Transcription' `
    -Name  'EnableInvocationHeader' `
    -Value 1 -Type DWord `
    -CISRef '18.10.87.2' -Description 'PowerShell Transcription: Include invocation headers'

# 18.10.89.1.2 WinRM Client: Disallow unencrypted traffic
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WinRM\Client' `
    -Name  'AllowUnencryptedTraffic' `
    -Value 0 -Type DWord `
    -CISRef '18.10.89.1.2' -Description 'WinRM Client: Disallow unencrypted traffic'

# 18.10.89.1.3 WinRM Client: Disallow Digest authentication
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WinRM\Client' `
    -Name  'AllowDigest' `
    -Value 0 -Type DWord `
    -CISRef '18.10.89.1.3' -Description 'WinRM Client: Disallow Digest authentication'

# 18.10.89.2.3 WinRM Service: Disallow unencrypted traffic
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WinRM\Service' `
    -Name  'AllowUnencryptedTraffic' `
    -Value 0 -Type DWord `
    -CISRef '18.10.89.2.3' -Description 'WinRM Service: Disallow unencrypted traffic'

# 18.10.92.2.1 Windows Store: Disable users from modifying settings
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft\WindowsStore' `
    -Name  'RemoveWindowsStore' `
    -Value 1 -Type DWord `
    -CISRef '18.10.92.2.1' -Description 'Disable Windows Store (server environments)'

# 18.10.93.1.1 Automatic Updates: No auto-restart with logged-on users
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU' `
    -Name  'NoAutoRebootWithLoggedOnUsers' `
    -Value 1 -Type DWord `
    -CISRef '18.10.93.1.1' -Description 'Do not auto-restart Windows Update with logged-on users'

# 18.10.93.2.2 Configure scheduled install day = 0 (every day)
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU' `
    -Name  'ScheduledInstallDay' `
    -Value 0 -Type DWord `
    -CISRef '18.10.93.2.2' -Description 'Windows Update scheduled install day = Every day'

# ─────────────────────────────────────────────────────────────
# SECTION 19: USER CONFIGURATION
# ─────────────────────────────────────────────────────────────
Write-Log "--- Section 19: User Configuration (HKCU-equivalent via HKLM Policy) ---" -Level INFO
Write-Log "[19.x] INFO - Section 19 controls (screen saver, toast, attachment security) should be" -Level INFO
Write-Log "[19.x] INFO - deployed via Group Policy User Configuration to apply per-user." -Level INFO
Write-Log "[19.x] INFO - Apply via GPO: User Configuration > Administrative Templates" -Level INFO

# 19.7.4.1 Attachment security: Do not preserve zone info
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Attachments' `
    -Name  'SaveZoneInformation' `
    -Value 2 -Type DWord `
    -CISRef '19.7.4.1' -Description 'Preserve zone information on attachments (do not strip)'

# 19.7.4.2 Notify antivirus programs when opening attachments
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Attachments' `
    -Name  'ScanWithAntiVirus' `
    -Value 3 -Type DWord `
    -CISRef '19.7.4.2' -Description 'Notify antivirus programs when opening attachments'

# 19.7.40.1 Always install with elevated privileges = Disabled (HKCU scope via machine policy)
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Installer' `
    -Name  'AlwaysInstallElevated' `
    -Value 0 -Type DWord `
    -CISRef '19.7.40.1' -Description 'Disable always install with elevated privileges (user scope)'

# ─────────────────────────────────────────────────────────────
# SUMMARY
# ─────────────────────────────────────────────────────────────
Write-Log "===== CIS P3 Lower Priority Controls - COMPLETE =====" -Level INFO
Write-Log "Log saved to: $LogPath" -Level INFO
Write-Log "NOTE: Section 19 controls require GPO User Configuration for full effect." -Level WARN
Write-Log "NOTE: Review P3 settings for applicability to your specific server role." -Level WARN
