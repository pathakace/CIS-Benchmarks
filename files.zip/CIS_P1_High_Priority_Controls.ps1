#Requires -RunAsAdministrator
<#
.SYNOPSIS
    CIS Level 1 Windows Server 2022 - P1 High Priority Controls
    Golden Image or Immediate Post-Launch (60 controls)

.DESCRIPTION
    Applies all P1 CIS Level 1 controls. These should be in the golden image
    or applied immediately via GPO/SSM at instance launch (within 1 hour).

.NOTES
    Author      : Enterprise Windows Architecture Team
    Version     : 1.0
    CIS Ref     : CIS Microsoft Windows Server 2022 Benchmark
    Priority    : P1 - High (Golden Image / Immediate Post-Launch)
    Run As      : Local Administrator or SYSTEM

.EXAMPLE
    .\CIS_P1_High_Priority_Controls.ps1
    .\CIS_P1_High_Priority_Controls.ps1 -WhatIf
    .\CIS_P1_High_Priority_Controls.ps1 -LogPath "C:\Logs\CIS_P1.log"
#>

[CmdletBinding(SupportsShouldProcess)]
param(
    [string]$LogPath = "C:\Windows\Logs\CIS_P1_Remediation_$(Get-Date -Format 'yyyyMMdd_HHmmss').log"
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

#region --- Helpers ---
function Write-Log {
    param([string]$Message, [ValidateSet('INFO','WARN','ERROR','OK')]$Level = 'INFO')
    $ts = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    $entry = "[$ts][$Level] $Message"
    Write-Host $entry -ForegroundColor $(switch($Level){'OK'{'Green'}'WARN'{'Yellow'}'ERROR'{'Red'}default{'Cyan'}})
    Add-Content -Path $LogPath -Value $entry -ErrorAction SilentlyContinue
}

function Set-RegistryValue {
    param(
        [string]$Path, [string]$Name, $Value,
        [string]$Type = 'DWord', [string]$CISRef, [string]$Description
    )
    try {
        if (-not (Test-Path $Path)) { New-Item -Path $Path -Force | Out-Null }
        if ($PSCmdlet.ShouldProcess("$Path\$Name", "Set to '$Value'")) {
            Set-ItemProperty -Path $Path -Name $Name -Value $Value -Type $Type -Force
            Write-Log "[$CISRef] OK - $Description" -Level OK
        }
    } catch { Write-Log "[$CISRef] FAILED - $Description : $_" -Level ERROR }
}

function Set-UserRight {
    param([string]$Privilege, [string]$Accounts, [string]$CISRef, [string]$Description)
    try {
        if ($PSCmdlet.ShouldProcess($Privilege, "Set to: $Accounts")) {
            $tmpCfg = [System.IO.Path]::GetTempFileName() + '.inf'
            $tmpDb  = [System.IO.Path]::GetTempFileName() + '.sdb'
            @"
[Unicode]
Unicode=yes
[Version]
signature="`$CHICAGO`$"
Revision=1
[Privilege Rights]
$Privilege = $Accounts
"@ | Set-Content -Path $tmpCfg -Encoding Unicode
            secedit /configure /db $tmpDb /cfg $tmpCfg /quiet
            Remove-Item $tmpCfg, $tmpDb -Force -ErrorAction SilentlyContinue
            Write-Log "[$CISRef] OK - $Description" -Level OK
        }
    } catch { Write-Log "[$CISRef] FAILED - $Description : $_" -Level ERROR }
}

function Set-AuditPolicy {
    param([string]$SubCategory, [string]$Setting, [string]$CISRef)
    try {
        if ($PSCmdlet.ShouldProcess($SubCategory, "Audit: $Setting")) {
            $success = if ($Setting -match 'Success') { 'enable' } else { 'disable' }
            $failure = if ($Setting -match 'Failure') { 'enable' } else { 'disable' }
            auditpol /set /subcategory:"$SubCategory" /success:$success /failure:$failure | Out-Null
            Write-Log "[$CISRef] OK - Audit $SubCategory = $Setting" -Level OK
        }
    } catch { Write-Log "[$CISRef] FAILED - Audit $SubCategory : $_" -Level ERROR }
}
#endregion

Write-Log "===== CIS P1 High Priority Controls - START =====" -Level INFO
Write-Log "Host: $env:COMPUTERNAME | OS: $((Get-WmiObject Win32_OperatingSystem).Caption)" -Level INFO

# ─────────────────────────────────────────────────────────────
# SECTION 1.1: PASSWORD POLICY
# ─────────────────────────────────────────────────────────────
Write-Log "--- Section 1.1: Password Policy ---" -Level INFO

# 1.1.3 Minimum password age >= 1 day
try {
    if ($PSCmdlet.ShouldProcess("Min Password Age", "Set to 1")) {
        net accounts /MINPWAGE:1 | Out-Null
        Write-Log "[1.1.3] OK - Minimum password age set to 1 day" -Level OK
    }
} catch { Write-Log "[1.1.3] FAILED - Min password age: $_" -Level ERROR }

# 1.1.6 Relax minimum password length limits = Enabled
Set-RegistryValue `
    -Path  'HKLM:\SYSTEM\CurrentControlSet\Control\SAM' `
    -Name  'RelaxMinimumPasswordLengthLimits' `
    -Value 1 -Type DWord `
    -CISRef '1.1.6' -Description 'Relax minimum password length limits (supports 14+ chars)'

# ─────────────────────────────────────────────────────────────
# SECTION 1.2: ACCOUNT LOCKOUT
# ─────────────────────────────────────────────────────────────
Write-Log "--- Section 1.2: Account Lockout ---" -Level INFO

# 1.2.3 Allow Administrator account lockout = Enabled
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' `
    -Name  'AllowAdministratorLockout' `
    -Value 1 -Type DWord `
    -CISRef '1.2.3' -Description 'Allow built-in Administrator account lockout'

# ─────────────────────────────────────────────────────────────
# SECTION 2.2: USER RIGHTS ASSIGNMENT
# ─────────────────────────────────────────────────────────────
Write-Log "--- Section 2.2: User Rights Assignment ---" -Level INFO

# 2.2.1 Access Credential Manager as trusted caller = No One
Set-UserRight -Privilege 'SeTrustedCredManAccessPrivilege' -Accounts '' `
    -CISRef '2.2.1' -Description 'Access Credential Manager as trusted caller = No One'

# 2.2.3 Access this computer from network = Administrators, Authenticated Users
Set-UserRight -Privilege 'SeNetworkLogonRight' -Accounts '*S-1-5-32-544,*S-1-5-11' `
    -CISRef '2.2.3' -Description 'Network access = Administrators + Authenticated Users'

# 2.2.4 Act as part of the operating system = No One
Set-UserRight -Privilege 'SeTcbPrivilege' -Accounts '' `
    -CISRef '2.2.4' -Description 'Act as part of OS = No One'

# 2.2.7 Allow log on locally = Administrators
Set-UserRight -Privilege 'SeInteractiveLogonRight' -Accounts '*S-1-5-32-544' `
    -CISRef '2.2.7' -Description 'Allow log on locally = Administrators only'

# 2.2.9 Allow log on through RDP = Administrators, Remote Desktop Users
Set-UserRight -Privilege 'SeRemoteInteractiveLogonRight' -Accounts '*S-1-5-32-544,*S-1-5-32-555' `
    -CISRef '2.2.9' -Description 'Allow RDP = Administrators + Remote Desktop Users'

# 2.2.14 Create a token object = No One
Set-UserRight -Privilege 'SeCreateTokenPrivilege' -Accounts '' `
    -CISRef '2.2.14' -Description 'Create a token object = No One'

# 2.2.16 Create permanent shared objects = No One
Set-UserRight -Privilege 'SeCreatePermanentPrivilege' -Accounts '' `
    -CISRef '2.2.16' -Description 'Create permanent shared objects = No One'

# 2.2.19 Debug programs = Administrators
Set-UserRight -Privilege 'SeDebugPrivilege' -Accounts '*S-1-5-32-544' `
    -CISRef '2.2.19' -Description 'Debug programs = Administrators only'

# 2.2.22 Deny log on as batch job to Guests
Set-UserRight -Privilege 'SeDenyBatchLogonRight' -Accounts '*S-1-5-32-546' `
    -CISRef '2.2.22' -Description 'Deny batch job logon to Guests'

# 2.2.23 Deny log on as service to Guests
Set-UserRight -Privilege 'SeDenyServiceLogonRight' -Accounts '*S-1-5-32-546' `
    -CISRef '2.2.23' -Description 'Deny service logon to Guests'

# 2.2.24 Deny log on locally to Guests
Set-UserRight -Privilege 'SeDenyInteractiveLogonRight' -Accounts '*S-1-5-32-546' `
    -CISRef '2.2.24' -Description 'Deny local logon to Guests'

# 2.2.28 Enable computer/user accounts to be trusted for delegation = No One
Set-UserRight -Privilege 'SeEnableDelegationPrivilege' -Accounts '' `
    -CISRef '2.2.28' -Description 'Trusted for delegation = No One'

# 2.2.30 Generate security audits = LOCAL SERVICE, NETWORK SERVICE
Set-UserRight -Privilege 'SeAuditPrivilege' -Accounts '*S-1-5-19,*S-1-5-20' `
    -CISRef '2.2.30' -Description 'Generate security audits = LOCAL SERVICE + NETWORK SERVICE'

# 2.2.35 Lock pages in memory = No One
Set-UserRight -Privilege 'SeLockMemoryPrivilege' -Accounts '' `
    -CISRef '2.2.35' -Description 'Lock pages in memory = No One'

# 2.2.38 Manage auditing and security log = Administrators
Set-UserRight -Privilege 'SeSecurityPrivilege' -Accounts '*S-1-5-32-544' `
    -CISRef '2.2.38' -Description 'Manage auditing and security log = Administrators'

# 2.2.39 Modify an object label = No One
Set-UserRight -Privilege 'SeRelabelPrivilege' -Accounts '' `
    -CISRef '2.2.39' -Description 'Modify an object label = No One'

# 2.2.44 Replace a process level token = LOCAL SERVICE, NETWORK SERVICE
Set-UserRight -Privilege 'SeAssignPrimaryTokenPrivilege' -Accounts '*S-1-5-19,*S-1-5-20' `
    -CISRef '2.2.44' -Description 'Replace process level token = LOCAL SERVICE + NETWORK SERVICE'

# ─────────────────────────────────────────────────────────────
# SECTION 2.3: SECURITY OPTIONS
# ─────────────────────────────────────────────────────────────
Write-Log "--- Section 2.3: Security Options ---" -Level INFO

# 2.3.2.1 Force audit policy subcategory settings
Set-RegistryValue `
    -Path  'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa' `
    -Name  'SCENoApplyLegacyAuditPolicy' `
    -Value 1 -Type DWord `
    -CISRef '2.3.2.1' -Description 'Force audit policy subcategory settings'

# 2.3.6.1 Domain member: Digitally encrypt secure channel data (always)
Set-RegistryValue `
    -Path  'HKLM:\SYSTEM\CurrentControlSet\Services\Netlogon\Parameters' `
    -Name  'RequireSignOrSeal' `
    -Value 1 -Type DWord `
    -CISRef '2.3.6.1' -Description 'Domain member: Encrypt secure channel (always)'

# 2.3.6.2 Domain member: Digitally encrypt secure channel (when possible)
Set-RegistryValue `
    -Path  'HKLM:\SYSTEM\CurrentControlSet\Services\Netlogon\Parameters' `
    -Name  'SealSecureChannel' `
    -Value 1 -Type DWord `
    -CISRef '2.3.6.2' -Description 'Domain member: Encrypt secure channel (when possible)'

# 2.3.6.3 Domain member: Digitally sign secure channel (when possible)
Set-RegistryValue `
    -Path  'HKLM:\SYSTEM\CurrentControlSet\Services\Netlogon\Parameters' `
    -Name  'SignSecureChannel' `
    -Value 1 -Type DWord `
    -CISRef '2.3.6.3' -Description 'Domain member: Sign secure channel (when possible)'

# 2.3.6.4 Disable machine account password changes = Disabled (allow changes)
Set-RegistryValue `
    -Path  'HKLM:\SYSTEM\CurrentControlSet\Services\Netlogon\Parameters' `
    -Name  'DisablePasswordChange' `
    -Value 0 -Type DWord `
    -CISRef '2.3.6.4' -Description 'Machine account password changes = Enabled'

# 2.3.6.5 Maximum machine account password age <= 30 days
Set-RegistryValue `
    -Path  'HKLM:\SYSTEM\CurrentControlSet\Services\Netlogon\Parameters' `
    -Name  'MaximumPasswordAge' `
    -Value 30 -Type DWord `
    -CISRef '2.3.6.5' -Description 'Maximum machine account password age = 30 days'

# 2.3.6.6 Domain member: Require strong session key
Set-RegistryValue `
    -Path  'HKLM:\SYSTEM\CurrentControlSet\Services\Netlogon\Parameters' `
    -Name  'RequireStrongKey' `
    -Value 1 -Type DWord `
    -CISRef '2.3.6.6' -Description 'Domain member: Require strong session key'

# 2.3.7.1 Do not require CTRL+ALT+DEL = Disabled (require it)
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' `
    -Name  'DisableCAD' `
    -Value 0 -Type DWord `
    -CISRef '2.3.7.1' -Description 'Require CTRL+ALT+DEL for logon'

# 2.3.8.1 Microsoft network client: Digitally sign communications (always)
Set-RegistryValue `
    -Path  'HKLM:\SYSTEM\CurrentControlSet\Services\LanmanWorkstation\Parameters' `
    -Name  'RequireSecuritySignature' `
    -Value 1 -Type DWord `
    -CISRef '2.3.8.1' -Description 'Network client: Digitally sign communications (always)'

# 2.3.8.2 Microsoft network client: Send unencrypted password = Disabled
Set-RegistryValue `
    -Path  'HKLM:\SYSTEM\CurrentControlSet\Services\LanmanWorkstation\Parameters' `
    -Name  'EnablePlainTextPassword' `
    -Value 0 -Type DWord `
    -CISRef '2.3.8.2' -Description 'Network client: No unencrypted passwords'

# 2.3.9.1 Microsoft network server: Idle disconnect <= 15 minutes
Set-RegistryValue `
    -Path  'HKLM:\SYSTEM\CurrentControlSet\Services\LanManServer\Parameters' `
    -Name  'AutoDisconnect' `
    -Value 15 -Type DWord `
    -CISRef '2.3.9.1' -Description 'Network server: Idle disconnect = 15 minutes'

# 2.3.9.2 Microsoft network server: Digitally sign communications (always)
Set-RegistryValue `
    -Path  'HKLM:\SYSTEM\CurrentControlSet\Services\LanManServer\Parameters' `
    -Name  'RequireSecuritySignature' `
    -Value 1 -Type DWord `
    -CISRef '2.3.9.2' -Description 'Network server: Digitally sign communications (always)'

# 2.3.9.3 Disconnect clients when logon hours expire
Set-RegistryValue `
    -Path  'HKLM:\SYSTEM\CurrentControlSet\Services\LanManServer\Parameters' `
    -Name  'EnableForcedLogOff' `
    -Value 1 -Type DWord `
    -CISRef '2.3.9.3' -Description 'Network server: Disconnect clients at logon hour expiry'

# 2.3.10.11 Restrict clients allowed to make remote calls to SAM
Set-RegistryValue `
    -Path  'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa' `
    -Name  'RestrictRemoteSAM' `
    -Value 'O:BAG:BAD:(A;;RC;;;BA)' -Type String `
    -CISRef '2.3.10.11' -Description 'Restrict remote SAM calls to Administrators only'

# 2.3.10.12 Shares accessible anonymously = None
Set-RegistryValue `
    -Path  'HKLM:\SYSTEM\CurrentControlSet\Services\LanManServer\Parameters' `
    -Name  'NullSessionShares' `
    -Value '' -Type MultiString `
    -CISRef '2.3.10.12' -Description 'No shares accessible anonymously'

# 2.3.10.13 Sharing and security model = Classic
Set-RegistryValue `
    -Path  'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa' `
    -Name  'ForceGuest' `
    -Value 0 -Type DWord `
    -CISRef '2.3.10.13' -Description 'Sharing and security model = Classic'

# 2.3.11.2 Allow LocalSystem NULL session fallback = Disabled
Set-RegistryValue `
    -Path  'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa\MSV1_0' `
    -Name  'allownullsessionfallback' `
    -Value 0 -Type DWord `
    -CISRef '2.3.11.2' -Description 'Disable LocalSystem NULL session fallback'

# 2.3.11.3 Allow PKU2U authentication = Disabled
Set-RegistryValue `
    -Path  'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa\pku2u' `
    -Name  'AllowOnlineID' `
    -Value 0 -Type DWord `
    -CISRef '2.3.11.3' -Description 'Disable PKU2U online identity authentication'

# 2.3.11.6 Force logoff when logon hours expire
Set-RegistryValue `
    -Path  'HKLM:\SYSTEM\CurrentControlSet\Services\LanManServer\Parameters' `
    -Name  'EnableForcedLogOff' `
    -Value 1 -Type DWord `
    -CISRef '2.3.11.6' -Description 'Force logoff when logon hours expire'

# 2.3.11.8 LDAP client signing requirements = Negotiate signing
Set-RegistryValue `
    -Path  'HKLM:\SYSTEM\CurrentControlSet\Services\LDAP' `
    -Name  'LDAPClientIntegrity' `
    -Value 1 -Type DWord `
    -CISRef '2.3.11.8' -Description 'LDAP client signing requirements = Negotiate signing'

# 2.3.11.9 Minimum session security for NTLM SSP clients (NTLMv2 + 128-bit)
Set-RegistryValue `
    -Path  'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa\MSV1_0' `
    -Name  'NtlmMinClientSec' `
    -Value 537395200 -Type DWord `
    -CISRef '2.3.11.9' -Description 'NTLM SSP clients: NTLMv2 + 128-bit encryption'

# 2.3.11.10 Minimum session security for NTLM SSP servers (NTLMv2 + 128-bit)
Set-RegistryValue `
    -Path  'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa\MSV1_0' `
    -Name  'NtlmMinServerSec' `
    -Value 537395200 -Type DWord `
    -CISRef '2.3.11.10' -Description 'NTLM SSP servers: NTLMv2 + 128-bit encryption'

# 2.3.13.1 Allow system shutdown without logon = Disabled
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' `
    -Name  'ShutdownWithoutLogon' `
    -Value 0 -Type DWord `
    -CISRef '2.3.13.1' -Description 'Require authentication to shut down system'

# 2.3.17.4 UAC: Detect application installations and prompt for elevation
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' `
    -Name  'EnableInstallerDetection' `
    -Value 1 -Type DWord `
    -CISRef '2.3.17.4' -Description 'UAC: Detect application installations'

# 2.3.17.5 UAC: Only elevate UIAccess applications in secure locations
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' `
    -Name  'EnableSecureUIAPaths' `
    -Value 1 -Type DWord `
    -CISRef '2.3.17.5' -Description 'UAC: Only elevate UIAccess apps in secure locations'

# 2.3.17.8 UAC: Virtualize file and registry write failures to per-user locations
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' `
    -Name  'EnableVirtualization' `
    -Value 1 -Type DWord `
    -CISRef '2.3.17.8' -Description 'UAC: Virtualize file/registry write failures'

# ─────────────────────────────────────────────────────────────
# SECTION 9: FIREWALL LOGGING
# ─────────────────────────────────────────────────────────────
Write-Log "--- Section 9: Firewall Logging ---" -Level INFO

try {
    if ($PSCmdlet.ShouldProcess("Firewall Profiles", "Configure logging")) {
        # 9.1.4 / 9.2.4 / 9.3.4 Disable notifications
        Set-NetFirewallProfile -Profile Domain  -NotifyOnListen False
        Set-NetFirewallProfile -Profile Private -NotifyOnListen False
        Set-NetFirewallProfile -Profile Public  -NotifyOnListen False
        Write-Log "[9.1.4/9.2.4/9.3.4] OK - Firewall notifications disabled on all profiles" -Level OK

        # 9.1.7 / 9.2.7 / 9.3.9 Log dropped packets
        Set-NetFirewallProfile -Profile Domain  -LogBlocked True
        Set-NetFirewallProfile -Profile Private -LogBlocked True
        Set-NetFirewallProfile -Profile Public  -LogBlocked True
        Write-Log "[9.1.7/9.2.7/9.3.9] OK - Log dropped packets enabled on all profiles" -Level OK
    }
} catch { Write-Log "[9.x Logging] FAILED - $_" -Level ERROR }

# ─────────────────────────────────────────────────────────────
# SECTION 17: AUDIT POLICY
# ─────────────────────────────────────────────────────────────
Write-Log "--- Section 17: Audit Policy ---" -Level INFO

Set-AuditPolicy -SubCategory 'Account Lockout'              -Setting 'Failure'             -CISRef '17.5.1'
Set-AuditPolicy -SubCategory 'Logoff'                       -Setting 'Success'             -CISRef '17.5.3'
Set-AuditPolicy -SubCategory 'Other Logon/Logoff Events'    -Setting 'Success and Failure' -CISRef '17.5.5'
Set-AuditPolicy -SubCategory 'Audit Policy Change'          -Setting 'Success'             -CISRef '17.7.1'
Set-AuditPolicy -SubCategory 'Authentication Policy Change' -Setting 'Success'             -CISRef '17.7.2'
Set-AuditPolicy -SubCategory 'Security State Change'        -Setting 'Success'             -CISRef '17.9.3'
Set-AuditPolicy -SubCategory 'System Integrity'             -Setting 'Success and Failure' -CISRef '17.9.5'

# ─────────────────────────────────────────────────────────────
# SECTION 18: ADDITIONAL SECURITY SETTINGS
# ─────────────────────────────────────────────────────────────
Write-Log "--- Section 18: Additional Security Settings ---" -Level INFO

# 18.4.1 Apply UAC restrictions to local accounts on network logons
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' `
    -Name  'LocalAccountTokenFilterPolicy' `
    -Value 0 -Type DWord `
    -CISRef '18.4.1' -Description 'Apply UAC restrictions to local accounts on network logons'

# 18.4.4 Configure RPC packet level privacy
Set-RegistryValue `
    -Path  'HKLM:\SYSTEM\CurrentControlSet\Control\Print\Providers\LanMan Print Services\Servers' `
    -Name  'AddPrinterDrivers' `
    -Value 1 -Type DWord `
    -CISRef '18.4.4' -Description 'Configure RPC packet level privacy'

# 18.5.8 MSS: Enable Safe DLL search mode
Set-RegistryValue `
    -Path  'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager' `
    -Name  'SafeDllSearchMode' `
    -Value 1 -Type DWord `
    -CISRef '18.5.8' -Description 'Enable Safe DLL search mode (prevents DLL hijacking)'

# 18.6.4.1 Configure DNS over HTTPS (DoH)
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\DNSClient' `
    -Name  'DoHPolicy' `
    -Value 2 -Type DWord `
    -CISRef '18.6.4.1' -Description 'Configure DNS over HTTPS = Require'

# 18.10.6.1 Block Microsoft accounts
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' `
    -Name  'NoConnectedUser' `
    -Value 3 -Type DWord `
    -CISRef '18.10.6.1' -Description 'Block Microsoft accounts'

# 18.10.7.2 Set default behavior for AutoRun = Do not execute
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer' `
    -Name  'NoAutorun' `
    -Value 1 -Type DWord `
    -CISRef '18.10.7.2' -Description 'AutoRun default: Do not execute'

# 18.10.7.3 Turn off Autoplay = All drives
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer' `
    -Name  'NoDriveTypeAutoRun' `
    -Value 255 -Type DWord `
    -CISRef '18.10.7.3' -Description 'Turn off Autoplay on all drives'

# 18.10.81.2 Always install with elevated privileges = Disabled (HKLM)
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Installer' `
    -Name  'AlwaysInstallElevated' `
    -Value 0 -Type DWord `
    -CISRef '18.10.81.2' -Description 'Disable always install with elevated privileges (machine)'

# 18.10.89.2.4 Disallow WinRM from storing RunAs credentials
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WinRM\Service' `
    -Name  'DisableRunAs' `
    -Value 1 -Type DWord `
    -CISRef '18.10.89.2.4' -Description 'WinRM: Disallow storing RunAs credentials'

# ─────────────────────────────────────────────────────────────
# SUMMARY
# ─────────────────────────────────────────────────────────────
Write-Log "===== CIS P1 High Priority Controls - COMPLETE =====" -Level INFO
Write-Log "Log saved to: $LogPath" -Level INFO
Write-Log "NOTE: A reboot is recommended to ensure all settings take full effect." -Level WARN
