#Requires -RunAsAdministrator
<#
.SYNOPSIS
    CIS Level 1 Windows Server 2022 - P2 Medium Priority Controls
    Post-Deployment via GPO (60 controls)

.DESCRIPTION
    Applies all P2 CIS Level 1 controls. These are applied after initial deployment
    via Group Policy or configuration management (within 24 hours of launch).

.NOTES
    Author      : Enterprise Windows Architecture Team
    Version     : 1.0
    CIS Ref     : CIS Microsoft Windows Server 2022 Benchmark
    Priority    : P2 - Medium (Post-Deployment, within 24h)
    Run As      : Local Administrator or SYSTEM

.EXAMPLE
    .\CIS_P2_Medium_Priority_Controls.ps1
    .\CIS_P2_Medium_Priority_Controls.ps1 -WhatIf
    .\CIS_P2_Medium_Priority_Controls.ps1 -LogPath "C:\Logs\CIS_P2.log"
    .\CIS_P2_Medium_Priority_Controls.ps1 -LegalNoticeText "Authorized use only." -LegalNoticeCaption "NOTICE"
#>

[CmdletBinding(SupportsShouldProcess)]
param(
    [string]$LogPath          = "C:\Windows\Logs\CIS_P2_Remediation_$(Get-Date -Format 'yyyyMMdd_HHmmss').log",
    [string]$LegalNoticeText  = "This system is for authorized use only. Unauthorized access is prohibited and may be subject to civil and criminal penalties.",
    [string]$LegalNoticeCaption = "AUTHORIZED ACCESS ONLY",
    [string]$FirewallLogFolder = "$env:SystemRoot\System32\logfiles\firewall"
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

#region --- Helpers ---
function Write-Log {
    param([string]$Message, [ValidateSet('INFO','WARN','ERROR','OK')]$Level = 'INFO')
    $ts = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    $entry = "[$ts][$Level] $Message"
    Write-Host $entry -ForegroundColor $(switch($Level){'OK'{'Green'}'WARN'{'Yellow'}'ERROR'{'Red'}default{'Cyan'}})
    Add-Content -Path $LogPath -Value $entry -ErrorAction SilentlyContinue
}

function Set-RegistryValue {
    param(
        [string]$Path, [string]$Name, $Value,
        [string]$Type = 'DWord', [string]$CISRef, [string]$Description
    )
    try {
        if (-not (Test-Path $Path)) { New-Item -Path $Path -Force | Out-Null }
        if ($PSCmdlet.ShouldProcess("$Path\$Name", "Set to '$Value'")) {
            Set-ItemProperty -Path $Path -Name $Name -Value $Value -Type $Type -Force
            Write-Log "[$CISRef] OK - $Description" -Level OK
        }
    } catch { Write-Log "[$CISRef] FAILED - $Description : $_" -Level ERROR }
}

function Set-UserRight {
    param([string]$Privilege, [string]$Accounts, [string]$CISRef, [string]$Description)
    try {
        if ($PSCmdlet.ShouldProcess($Privilege, "Set to: $Accounts")) {
            $tmpCfg = [System.IO.Path]::GetTempFileName() + '.inf'
            $tmpDb  = [System.IO.Path]::GetTempFileName() + '.sdb'
            @"
[Unicode]
Unicode=yes
[Version]
signature="`$CHICAGO`$"
Revision=1
[Privilege Rights]
$Privilege = $Accounts
"@ | Set-Content -Path $tmpCfg -Encoding Unicode
            secedit /configure /db $tmpDb /cfg $tmpCfg /quiet
            Remove-Item $tmpCfg, $tmpDb -Force -ErrorAction SilentlyContinue
            Write-Log "[$CISRef] OK - $Description" -Level OK
        }
    } catch { Write-Log "[$CISRef] FAILED - $Description : $_" -Level ERROR }
}

function Set-AuditPolicy {
    param([string]$SubCategory, [string]$Setting, [string]$CISRef)
    try {
        if ($PSCmdlet.ShouldProcess($SubCategory, "Audit: $Setting")) {
            $s = if ($Setting -match 'Success') { 'enable' } else { 'disable' }
            $f = if ($Setting -match 'Failure') { 'enable' } else { 'disable' }
            auditpol /set /subcategory:"$SubCategory" /success:$s /failure:$f | Out-Null
            Write-Log "[$CISRef] OK - Audit $SubCategory = $Setting" -Level OK
        }
    } catch { Write-Log "[$CISRef] FAILED - Audit $SubCategory : $_" -Level ERROR }
}
#endregion

Write-Log "===== CIS P2 Medium Priority Controls - START =====" -Level INFO
Write-Log "Host: $env:COMPUTERNAME | OS: $((Get-WmiObject Win32_OperatingSystem).Caption)" -Level INFO

# ─────────────────────────────────────────────────────────────
# SECTION 2.2: USER RIGHTS ASSIGNMENT
# ─────────────────────────────────────────────────────────────
Write-Log "--- Section 2.2: User Rights Assignment ---" -Level INFO

# 2.2.6 Adjust memory quotas = Administrators, LOCAL SERVICE, NETWORK SERVICE
Set-UserRight -Privilege 'SeIncreaseQuotaPrivilege' -Accounts '*S-1-5-32-544,*S-1-5-19,*S-1-5-20' `
    -CISRef '2.2.6' -Description 'Adjust memory quotas = Admins + LOCAL/NETWORK SERVICE'

# 2.2.11 Change system time = Administrators, LOCAL SERVICE
Set-UserRight -Privilege 'SeSystemtimePrivilege' -Accounts '*S-1-5-32-544,*S-1-5-19' `
    -CISRef '2.2.11' -Description 'Change system time = Administrators + LOCAL SERVICE'

# 2.2.12 Change time zone = Administrators, LOCAL SERVICE, Users
Set-UserRight -Privilege 'SeTimeZonePrivilege' -Accounts '*S-1-5-32-544,*S-1-5-19,*S-1-5-32-545' `
    -CISRef '2.2.12' -Description 'Change time zone = Admins + LOCAL SERVICE + Users'

# 2.2.13 Create a pagefile = Administrators
Set-UserRight -Privilege 'SeCreatePagefilePrivilege' -Accounts '*S-1-5-32-544' `
    -CISRef '2.2.13' -Description 'Create a pagefile = Administrators'

# 2.2.15 Create global objects = Administrators, LOCAL SERVICE, NETWORK SERVICE, SERVICE
Set-UserRight -Privilege 'SeCreateGlobalPrivilege' -Accounts '*S-1-5-32-544,*S-1-5-19,*S-1-5-20,*S-1-5-6' `
    -CISRef '2.2.15' -Description 'Create global objects = Admins + SERVICE accounts'

# 2.2.18 Create symbolic links = Administrators
Set-UserRight -Privilege 'SeCreateSymbolicLinkPrivilege' -Accounts '*S-1-5-32-544' `
    -CISRef '2.2.18' -Description 'Create symbolic links = Administrators'

# 2.2.29 Force shutdown from remote = Administrators
Set-UserRight -Privilege 'SeRemoteShutdownPrivilege' -Accounts '*S-1-5-32-544' `
    -CISRef '2.2.29' -Description 'Force shutdown from remote = Administrators'

# 2.2.32 Impersonate a client after authentication = Admins, LOCAL/NETWORK SERVICE, SERVICE
Set-UserRight -Privilege 'SeImpersonatePrivilege' -Accounts '*S-1-5-32-544,*S-1-5-19,*S-1-5-20,*S-1-5-6' `
    -CISRef '2.2.32' -Description 'Impersonate client after auth = Admins + SERVICE accounts'

# 2.2.33 Increase scheduling priority = Administrators, Window Manager\Window Manager Group
Set-UserRight -Privilege 'SeIncreaseBasePriorityPrivilege' -Accounts '*S-1-5-32-544' `
    -CISRef '2.2.33' -Description 'Increase scheduling priority = Administrators'

# 2.2.34 Load and unload device drivers = Administrators
Set-UserRight -Privilege 'SeLoadDriverPrivilege' -Accounts '*S-1-5-32-544' `
    -CISRef '2.2.34' -Description 'Load/unload device drivers = Administrators'

# 2.2.40 Modify firmware environment values = Administrators
Set-UserRight -Privilege 'SeSystemEnvironmentPrivilege' -Accounts '*S-1-5-32-544' `
    -CISRef '2.2.40' -Description 'Modify firmware environment = Administrators'

# 2.2.41 Perform volume maintenance tasks = Administrators
Set-UserRight -Privilege 'SeManageVolumePrivilege' -Accounts '*S-1-5-32-544' `
    -CISRef '2.2.41' -Description 'Perform volume maintenance = Administrators'

# 2.2.42 Profile a single process = Administrators
Set-UserRight -Privilege 'SeProfileSingleProcessPrivilege' -Accounts '*S-1-5-32-544' `
    -CISRef '2.2.42' -Description 'Profile single process = Administrators'

# 2.2.43 Profile system performance = Administrators, WMI Performance Adapter
Set-UserRight -Privilege 'SeSystemProfilePrivilege' -Accounts '*S-1-5-32-544,*S-1-5-80-3139157870-2983391045-3678747466-658725712-1809340420' `
    -CISRef '2.2.43' -Description 'Profile system performance = Administrators + WMI Adapter'

# 2.2.45 Restore files and directories = Administrators
Set-UserRight -Privilege 'SeRestorePrivilege' -Accounts '*S-1-5-32-544' `
    -CISRef '2.2.45' -Description 'Restore files and directories = Administrators'

# 2.2.46 Shut down the system = Administrators
Set-UserRight -Privilege 'SeShutdownPrivilege' -Accounts '*S-1-5-32-544' `
    -CISRef '2.2.46' -Description 'Shut down the system = Administrators'

# 2.2.48 Take ownership of files or other objects = Administrators
Set-UserRight -Privilege 'SeTakeOwnershipPrivilege' -Accounts '*S-1-5-32-544' `
    -CISRef '2.2.48' -Description 'Take ownership = Administrators'

# ─────────────────────────────────────────────────────────────
# SECTION 2.3: SECURITY OPTIONS
# ─────────────────────────────────────────────────────────────
Write-Log "--- Section 2.3: Security Options ---" -Level INFO

# 2.3.4.1 Allowed to format removable media = Administrators
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon' `
    -Name  'AllocateDASD' `
    -Value '0' -Type String `
    -CISRef '2.3.4.1' -Description 'Format removable media = Administrators only'

# 2.3.4.2 Prevent users from installing printer drivers
Set-RegistryValue `
    -Path  'HKLM:\SYSTEM\CurrentControlSet\Control\Print\Providers\LanMan Print Services\Servers' `
    -Name  'AddPrinterDrivers' `
    -Value 1 -Type DWord `
    -CISRef '2.3.4.2' -Description 'Prevent users from installing printer drivers'

# 2.3.7.3 Machine inactivity limit <= 900 seconds
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' `
    -Name  'InactivityTimeoutSecs' `
    -Value 900 -Type DWord `
    -CISRef '2.3.7.3' -Description 'Machine inactivity limit = 900 seconds (15 min)'

# 2.3.7.4 Interactive logon message text (Legal Notice)
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' `
    -Name  'LegalNoticeText' `
    -Value $LegalNoticeText -Type String `
    -CISRef '2.3.7.4' -Description 'Interactive logon: Legal notice message text'

# 2.3.7.5 Interactive logon message title (Legal Notice)
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' `
    -Name  'LegalNoticeCaption' `
    -Value $LegalNoticeCaption -Type String `
    -CISRef '2.3.7.5' -Description 'Interactive logon: Legal notice caption'

# 2.3.7.7 Prompt password change 5-14 days before expiration
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon' `
    -Name  'PasswordExpiryWarning' `
    -Value 14 -Type DWord `
    -CISRef '2.3.7.7' -Description 'Prompt password change warning = 14 days'

# 2.3.7.8 Require DC authentication to unlock
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon' `
    -Name  'ForceUnlockLogon' `
    -Value 1 -Type DWord `
    -CISRef '2.3.7.8' -Description 'Require DC authentication to unlock workstation'

# 2.3.7.9 Smart card removal behavior = Lock workstation
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon' `
    -Name  'ScRemoveOption' `
    -Value '1' -Type String `
    -CISRef '2.3.7.9' -Description 'Smart card removal = Lock workstation'

# 2.3.9.4 Microsoft network server: Server SPN target name validation
Set-RegistryValue `
    -Path  'HKLM:\SYSTEM\CurrentControlSet\Services\LanManServer\Parameters' `
    -Name  'SMBServerNameHardeningLevel' `
    -Value 1 -Type DWord `
    -CISRef '2.3.9.4' -Description 'Server SPN target name validation = Accept if provided'

# 2.3.10.7 Named Pipes accessible anonymously = None
Set-RegistryValue `
    -Path  'HKLM:\SYSTEM\CurrentControlSet\Services\LanManServer\Parameters' `
    -Name  'NullSessionPipes' `
    -Value '' -Type MultiString `
    -CISRef '2.3.10.7' -Description 'No Named Pipes accessible anonymously'

# 2.3.10.8 Remotely accessible registry paths
Set-RegistryValue `
    -Path  'HKLM:\SYSTEM\CurrentControlSet\Control\SecurePipeServers\Winreg\AllowedExactPaths' `
    -Name  'Machine' `
    -Value @('System\CurrentControlSet\Control\ProductOptions','System\CurrentControlSet\Control\Server Applications','Software\Microsoft\Windows NT\CurrentVersion') -Type MultiString `
    -CISRef '2.3.10.8' -Description 'Remotely accessible registry paths (restricted set)'

# 2.3.10.9 Remotely accessible registry paths and sub-paths
Set-RegistryValue `
    -Path  'HKLM:\SYSTEM\CurrentControlSet\Control\SecurePipeServers\Winreg\AllowedPaths' `
    -Name  'Machine' `
    -Value @('Software\Microsoft\Windows NT\CurrentVersion\Print','Software\Microsoft\Windows NT\CurrentVersion\Windows','System\CurrentControlSet\Control\Print\Printers','System\CurrentControlSet\Services\Eventlog','Software\Microsoft\OLAP Server','System\CurrentControlSet\Control\ContentIndex','System\CurrentControlSet\Control\Terminal Server','System\CurrentControlSet\Control\Terminal Server\UserConfig','System\CurrentControlSet\Control\Terminal Server\DefaultUserConfiguration','Software\Microsoft\Windows NT\CurrentVersion\Perflib','System\CurrentControlSet\Services\SysmonLog') -Type MultiString `
    -CISRef '2.3.10.9' -Description 'Remotely accessible registry sub-paths (restricted set)'

# 2.3.11.1 Allow Local System to use computer identity for NTLM = Enabled (correct default)
Set-RegistryValue `
    -Path  'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa\MSV1_0' `
    -Name  'UseMachineId' `
    -Value 1 -Type DWord `
    -CISRef '2.3.11.1' -Description 'Allow LocalSystem NTLM identity = Enabled'

# 2.3.15.1 System objects: Require case insensitivity for non-Windows subsystems
Set-RegistryValue `
    -Path  'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Kernel' `
    -Name  'ObCaseInsensitive' `
    -Value 1 -Type DWord `
    -CISRef '2.3.15.1' -Description 'Require case insensitivity for non-Windows subsystems'

# 2.3.15.2 System objects: Strengthen default permissions of internal system objects
Set-RegistryValue `
    -Path  'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager' `
    -Name  'ProtectionMode' `
    -Value 1 -Type DWord `
    -CISRef '2.3.15.2' -Description 'Strengthen default permissions of internal system objects'

# ─────────────────────────────────────────────────────────────
# SECTION 9: FIREWALL LOGGING (Paths and Sizes)
# ─────────────────────────────────────────────────────────────
Write-Log "--- Section 9: Firewall Log Configuration ---" -Level INFO

try {
    if ($PSCmdlet.ShouldProcess("Firewall Logging", "Configure paths, size, and successful connections")) {
        if (-not (Test-Path $FirewallLogFolder)) {
            New-Item -Path $FirewallLogFolder -ItemType Directory -Force | Out-Null
        }
        # 9.1.5-8 Domain
        Set-NetFirewallProfile -Profile Domain  -LogFileName "$FirewallLogFolder\domain.log" -LogMaxSizeKilobytes 16384 -LogAllowed True
        # 9.2.5-8 Private
        Set-NetFirewallProfile -Profile Private -LogFileName "$FirewallLogFolder\private.log" -LogMaxSizeKilobytes 16384 -LogAllowed True
        # 9.3.7-10 Public + outbound allow
        Set-NetFirewallProfile -Profile Public  -LogFileName "$FirewallLogFolder\public.log"  -LogMaxSizeKilobytes 16384 -LogAllowed True
        Set-NetFirewallProfile -Profile Public  -DefaultOutboundAction Allow
        # 9.3.6 Public: Disable local connection security rules
        Set-NetFirewallProfile -Profile Public  -AllowLocalIPsecRules False

        Write-Log "[9.1.5/9.2.5/9.3.7] OK - Firewall log paths configured" -Level OK
        Write-Log "[9.1.6/9.2.6/9.3.8] OK - Firewall log size = 16 MB" -Level OK
        Write-Log "[9.1.8/9.2.8/9.3.10] OK - Log successful connections enabled" -Level OK
        Write-Log "[9.3.3] OK - Public profile outbound = Allow" -Level OK
        Write-Log "[9.3.6] OK - Public: local connection security rules disabled" -Level OK
    }
} catch { Write-Log "[9.x Log Config] FAILED - $_" -Level ERROR }

# ─────────────────────────────────────────────────────────────
# SECTION 17: AUDIT POLICY
# ─────────────────────────────────────────────────────────────
Write-Log "--- Section 17: Audit Policy ---" -Level INFO

Set-AuditPolicy -SubCategory 'Application Group Management' -Setting 'Success and Failure' -CISRef '17.2.1'
Set-AuditPolicy -SubCategory 'Security Group Management'    -Setting 'Success'             -CISRef '17.2.5'
Set-AuditPolicy -SubCategory 'Plug and Play Events'         -Setting 'Success'             -CISRef '17.3.1'
Set-AuditPolicy -SubCategory 'Process Creation'             -Setting 'Success'             -CISRef '17.3.2'
Set-AuditPolicy -SubCategory 'Group Membership'             -Setting 'Success'             -CISRef '17.5.2'
Set-AuditPolicy -SubCategory 'Detailed File Share'          -Setting 'Failure'             -CISRef '17.6.1'
Set-AuditPolicy -SubCategory 'File Share'                   -Setting 'Success and Failure' -CISRef '17.6.2'
Set-AuditPolicy -SubCategory 'Other Object Access Events'   -Setting 'Success and Failure' -CISRef '17.6.3'
Set-AuditPolicy -SubCategory 'Removable Storage'            -Setting 'Success and Failure' -CISRef '17.6.4'
Set-AuditPolicy -SubCategory 'Authorization Policy Change'  -Setting 'Success'             -CISRef '17.7.3'
Set-AuditPolicy -SubCategory 'MPSSVC Rule-Level Policy Change' -Setting 'Success and Failure' -CISRef '17.7.4'
Set-AuditPolicy -SubCategory 'Other Policy Change Events'   -Setting 'Failure'             -CISRef '17.7.5'
Set-AuditPolicy -SubCategory 'Sensitive Privilege Use'      -Setting 'Success and Failure' -CISRef '17.8.1'
Set-AuditPolicy -SubCategory 'IPsec Driver'                 -Setting 'Success and Failure' -CISRef '17.9.1'
Set-AuditPolicy -SubCategory 'Other System Events'          -Setting 'Success and Failure' -CISRef '17.9.2'
Set-AuditPolicy -SubCategory 'Security System Extension'    -Setting 'Success'             -CISRef '17.9.4'

# ─────────────────────────────────────────────────────────────
# SECTION 18.9.26: LAPS CONTROLS
# ─────────────────────────────────────────────────────────────
Write-Log "--- Section 18.9.26: LAPS ---" -Level INFO

# Check if LAPS is installed before applying
$lapsInstalled = Get-Command 'Get-LapsADPassword' -ErrorAction SilentlyContinue

# 18.9.26.x LAPS - four controls
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft Services\AdmPwd' `
    -Name  'AdmPwdEnabled' `
    -Value 1 -Type DWord `
    -CISRef '18.9.26.1' -Description 'LAPS: Enable local admin password management'

Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft Services\AdmPwd' `
    -Name  'PasswordAgeDays' `
    -Value 30 -Type DWord `
    -CISRef '18.9.26.2' -Description 'LAPS: Password age = 30 days'

Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft Services\AdmPwd' `
    -Name  'PasswordComplexity' `
    -Value 4 -Type DWord `
    -CISRef '18.9.26.3' -Description 'LAPS: Password complexity = Large letters + small + numbers + specials'

Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft Services\AdmPwd' `
    -Name  'PasswordLength' `
    -Value 15 -Type DWord `
    -CISRef '18.9.26.4' -Description 'LAPS: Password length = 15'

if (-not $lapsInstalled) {
    Write-Log "[18.9.26] WARN - LAPS PowerShell module not found. Registry keys set but verify LAPS is deployed." -Level WARN
}

# ─────────────────────────────────────────────────────────────
# SECTION 18.10: UI SECURITY
# ─────────────────────────────────────────────────────────────
Write-Log "--- Section 18.10: UI Security ---" -Level INFO

# 18.10.14.1 Do not display the password reveal button
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredUI' `
    -Name  'DisablePasswordReveal' `
    -Value 1 -Type DWord `
    -CISRef '18.10.14.1' -Description 'Do not display password reveal button'

# 18.10.14.2 Enumerate administrator accounts on elevation
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\CredUI' `
    -Name  'EnumerateAdministrators' `
    -Value 0 -Type DWord `
    -CISRef '18.10.14.2' -Description 'Do not enumerate administrator accounts on elevation'

# ─────────────────────────────────────────────────────────────
# SUMMARY
# ─────────────────────────────────────────────────────────────
Write-Log "===== CIS P2 Medium Priority Controls - COMPLETE =====" -Level INFO
Write-Log "Log saved to: $LogPath" -Level INFO
Write-Log "NOTE: A reboot may be required for some settings to take full effect." -Level WARN
