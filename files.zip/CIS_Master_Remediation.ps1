#Requires -RunAsAdministrator
<#
.SYNOPSIS
    CIS Level 1 Windows Server 2022 - Master Orchestration Script
    Runs P0 through P3 remediation scripts in sequence.

.DESCRIPTION
    Orchestrates all four CIS priority-level scripts. By default, only P0 runs.
    Pass -RunAll or specific -RunP1/-RunP2/-RunP3 switches to include higher tiers.

.NOTES
    Author  : Enterprise Windows Architecture Team
    Version : 1.0

.EXAMPLE
    # Run P0 only (golden image baseline)
    .\CIS_Master_Remediation.ps1

    # Run P0 + P1 (golden image + immediate post-launch)
    .\CIS_Master_Remediation.ps1 -RunP1

    # Run all priorities
    .\CIS_Master_Remediation.ps1 -RunAll

    # Dry-run all priorities
    .\CIS_Master_Remediation.ps1 -RunAll -WhatIf
#>

[CmdletBinding(SupportsShouldProcess)]
param(
    [switch]$RunP1,
    [switch]$RunP2,
    [switch]$RunP3,
    [switch]$RunAll,
    [string]$ScriptDir = $PSScriptRoot,
    [string]$LogDir    = "C:\Windows\Logs"
)

$ts = Get-Date -Format 'yyyyMMdd_HHmmss'

function Invoke-CISScript {
    param([string]$Name, [string]$Path)
    Write-Host "`n========================================" -ForegroundColor Magenta
    Write-Host " Running: $Name" -ForegroundColor Magenta
    Write-Host "========================================`n" -ForegroundColor Magenta
    if (Test-Path $Path) {
        if ($PSCmdlet.ShouldProcess($Name, "Execute")) {
            & $Path -LogPath "$LogDir\${Name}_$ts.log"
        }
    } else {
        Write-Warning "Script not found: $Path"
    }
}

# Always run P0
Invoke-CISScript -Name 'CIS_P0_Critical' -Path "$ScriptDir\CIS_P0_Critical_Controls.ps1"

if ($RunP1 -or $RunAll) {
    Invoke-CISScript -Name 'CIS_P1_High' -Path "$ScriptDir\CIS_P1_High_Priority_Controls.ps1"
}

if ($RunP2 -or $RunAll) {
    Invoke-CISScript -Name 'CIS_P2_Medium' -Path "$ScriptDir\CIS_P2_Medium_Priority_Controls.ps1"
}

if ($RunP3 -or $RunAll) {
    Invoke-CISScript -Name 'CIS_P3_Lower' -Path "$ScriptDir\CIS_P3_Lower_Priority_Controls.ps1"
}

Write-Host "`n========================================" -ForegroundColor Green
Write-Host " CIS Remediation Complete" -ForegroundColor Green
Write-Host " Logs: $LogDir" -ForegroundColor Green
Write-Host "========================================`n" -ForegroundColor Green

Write-Host "Reboot recommended to apply all settings." -ForegroundColor Yellow
