#Requires -RunAsAdministrator
<#
.SYNOPSIS
    CIS Level 1 Windows Server 2022 - P0 Critical Controls
    Golden Image Must-Haves (50 controls)

.DESCRIPTION
    Applies all P0 CIS Level 1 controls that must be baked into the AMI.
    These prevent credential theft, initial compromise, and provide forensic visibility.

.NOTES
    Author      : Enterprise Windows Architecture Team
    Version     : 1.0
    CIS Ref     : CIS Microsoft Windows Server 2022 Benchmark
    Priority    : P0 - Critical (Golden Image)
    Run As      : Local Administrator or SYSTEM

.EXAMPLE
    .\CIS_P0_Critical_Controls.ps1
    .\CIS_P0_Critical_Controls.ps1 -WhatIf
    .\CIS_P0_Critical_Controls.ps1 -LogPath "C:\Logs\CIS_P0.log"
#>

[CmdletBinding(SupportsShouldProcess)]
param(
    [string]$LogPath = "C:\Windows\Logs\CIS_P0_Remediation_$(Get-Date -Format 'yyyyMMdd_HHmmss').log"
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

#region --- Logging ---
function Write-Log {
    param([string]$Message, [ValidateSet('INFO','WARN','ERROR','OK')]$Level = 'INFO')
    $timestamp = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    $entry = "[$timestamp][$Level] $Message"
    Write-Host $entry -ForegroundColor $(switch($Level){'OK'{'Green'}'WARN'{'Yellow'}'ERROR'{'Red'}default{'Cyan'}})
    Add-Content -Path $LogPath -Value $entry -ErrorAction SilentlyContinue
}

function Set-RegistryValue {
    param(
        [string]$Path,
        [string]$Name,
        $Value,
        [string]$Type = 'DWord',
        [string]$CISRef,
        [string]$Description
    )
    try {
        if (-not (Test-Path $Path)) {
            New-Item -Path $Path -Force | Out-Null
        }
        if ($PSCmdlet.ShouldProcess("$Path\$Name", "Set to '$Value'")) {
            Set-ItemProperty -Path $Path -Name $Name -Value $Value -Type $Type -Force
            Write-Log "[$CISRef] OK - $Description" -Level OK
        }
    } catch {
        Write-Log "[$CISRef] FAILED - $Description : $_" -Level ERROR
    }
}
#endregion

Write-Log "===== CIS P0 Critical Controls - START =====" -Level INFO
Write-Log "Host: $env:COMPUTERNAME | OS: $((Get-WmiObject Win32_OperatingSystem).Caption)" -Level INFO

# ─────────────────────────────────────────────────────────────
# SECTION 1: PASSWORD POLICY (1.1.x)
# ─────────────────────────────────────────────────────────────
Write-Log "--- Section 1.1: Password Policy ---" -Level INFO

# 1.1.1 Enforce password history = 24
try {
    if ($PSCmdlet.ShouldProcess("Password History", "Set to 24")) {
        $tmpCfg = [System.IO.Path]::GetTempFileName()
        secedit /export /cfg $tmpCfg /quiet
        $cfg = Get-Content $tmpCfg
        $cfg = $cfg -replace 'PasswordHistorySize\s*=\s*\d+', 'PasswordHistorySize = 24'
        if ($cfg -notmatch 'PasswordHistorySize') { $cfg += "`nPasswordHistorySize = 24" }
        $cfg | Set-Content $tmpCfg
        secedit /configure /db "$env:TEMP\secedit.sdb" /cfg $tmpCfg /quiet
        Remove-Item $tmpCfg -Force
        Write-Log "[1.1.1] OK - Password history set to 24" -Level OK
    }
} catch { Write-Log "[1.1.1] FAILED - Password history: $_" -Level ERROR }

# 1.1.2 Maximum password age <= 365 days (already TRUE per baseline, enforcing 365)
try {
    if ($PSCmdlet.ShouldProcess("Max Password Age", "Set to 365")) {
        net accounts /MAXPWAGE:365 | Out-Null
        Write-Log "[1.1.2] OK - Maximum password age set to 365 days" -Level OK
    }
} catch { Write-Log "[1.1.2] FAILED - Max password age: $_" -Level ERROR }

# 1.1.4 Minimum password length >= 14
try {
    if ($PSCmdlet.ShouldProcess("Min Password Length", "Set to 14")) {
        net accounts /MINPWLEN:14 | Out-Null
        Write-Log "[1.1.4] OK - Minimum password length set to 14" -Level OK
    }
} catch { Write-Log "[1.1.4] FAILED - Min password length: $_" -Level ERROR }

# 1.1.5 Password complexity = Enabled
try {
    if ($PSCmdlet.ShouldProcess("Password Complexity", "Enable")) {
        $tmpCfg = [System.IO.Path]::GetTempFileName()
        secedit /export /cfg $tmpCfg /quiet
        $cfg = Get-Content $tmpCfg
        $cfg = $cfg -replace 'PasswordComplexity\s*=\s*\d', 'PasswordComplexity = 1'
        if ($cfg -notmatch 'PasswordComplexity') { $cfg += "`nPasswordComplexity = 1" }
        $cfg | Set-Content $tmpCfg
        secedit /configure /db "$env:TEMP\secedit.sdb" /cfg $tmpCfg /quiet
        Remove-Item $tmpCfg -Force
        Write-Log "[1.1.5] OK - Password complexity enabled" -Level OK
    }
} catch { Write-Log "[1.1.5] FAILED - Password complexity: $_" -Level ERROR }

# 1.1.7 Store passwords using reversible encryption = Disabled
try {
    if ($PSCmdlet.ShouldProcess("Reversible Encryption", "Disable")) {
        $tmpCfg = [System.IO.Path]::GetTempFileName()
        secedit /export /cfg $tmpCfg /quiet
        $cfg = Get-Content $tmpCfg
        $cfg = $cfg -replace 'ClearTextPassword\s*=\s*\d', 'ClearTextPassword = 0'
        if ($cfg -notmatch 'ClearTextPassword') { $cfg += "`nClearTextPassword = 0" }
        $cfg | Set-Content $tmpCfg
        secedit /configure /db "$env:TEMP\secedit.sdb" /cfg $tmpCfg /quiet
        Remove-Item $tmpCfg -Force
        Write-Log "[1.1.7] OK - Reversible encryption disabled" -Level OK
    }
} catch { Write-Log "[1.1.7] FAILED - Reversible encryption: $_" -Level ERROR }

# ─────────────────────────────────────────────────────────────
# SECTION 1.2: ACCOUNT LOCKOUT POLICY
# ─────────────────────────────────────────────────────────────
Write-Log "--- Section 1.2: Account Lockout Policy ---" -Level INFO

# 1.2.1 Account lockout duration >= 15 minutes
try {
    if ($PSCmdlet.ShouldProcess("Lockout Duration", "Set to 15")) {
        net accounts /LOCKOUTDURATION:15 | Out-Null
        Write-Log "[1.2.1] OK - Account lockout duration set to 15 minutes" -Level OK
    }
} catch { Write-Log "[1.2.1] FAILED - Lockout duration: $_" -Level ERROR }

# 1.2.2 Account lockout threshold <= 5 attempts
try {
    if ($PSCmdlet.ShouldProcess("Lockout Threshold", "Set to 5")) {
        net accounts /LOCKOUTTHRESHOLD:5 | Out-Null
        Write-Log "[1.2.2] OK - Account lockout threshold set to 5 attempts" -Level OK
    }
} catch { Write-Log "[1.2.2] FAILED - Lockout threshold: $_" -Level ERROR }

# 1.2.4 Reset account lockout counter >= 15 minutes
try {
    if ($PSCmdlet.ShouldProcess("Lockout Observation Window", "Set to 15")) {
        net accounts /LOCKOUTWINDOW:15 | Out-Null
        Write-Log "[1.2.4] OK - Lockout observation window set to 15 minutes" -Level OK
    }
} catch { Write-Log "[1.2.4] FAILED - Lockout window: $_" -Level ERROR }

# ─────────────────────────────────────────────────────────────
# SECTION 2.3.1: ACCOUNTS POLICIES
# ─────────────────────────────────────────────────────────────
Write-Log "--- Section 2.3.1: Accounts Policies ---" -Level INFO

# 2.3.1.1 Guest account = Disabled
try {
    if ($PSCmdlet.ShouldProcess("Guest Account", "Disable")) {
        Disable-LocalUser -Name 'Guest' -ErrorAction SilentlyContinue
        Write-Log "[2.3.1.1] OK - Guest account disabled" -Level OK
    }
} catch { Write-Log "[2.3.1.1] FAILED - Guest account: $_" -Level ERROR }

# 2.3.1.2 Limit blank passwords to console logon only
Set-RegistryValue `
    -Path  'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa' `
    -Name  'LimitBlankPasswordUse' `
    -Value 1 -Type DWord `
    -CISRef '2.3.1.2' -Description 'Limit blank passwords to console only'

# 2.3.1.3 Rename Administrator account
try {
    if ($PSCmdlet.ShouldProcess("Administrator Account", "Rename to SvcAdmin")) {
        $admin = Get-LocalUser | Where-Object { $_.SID -like '*-500' }
        if ($admin -and $admin.Name -eq 'Administrator') {
            Rename-LocalUser -Name 'Administrator' -NewName 'SvcAdmin'
            Write-Log "[2.3.1.3] OK - Administrator account renamed to SvcAdmin" -Level OK
        } else {
            Write-Log "[2.3.1.3] INFO - Administrator account already renamed ($($admin.Name))" -Level OK
        }
    }
} catch { Write-Log "[2.3.1.3] FAILED - Rename admin: $_" -Level ERROR }

# 2.3.1.4 Rename Guest account
try {
    if ($PSCmdlet.ShouldProcess("Guest Account", "Rename to SvcGuest")) {
        $guest = Get-LocalUser | Where-Object { $_.SID -like '*-501' }
        if ($guest -and $guest.Name -eq 'Guest') {
            Rename-LocalUser -Name 'Guest' -NewName 'SvcGuest'
            Write-Log "[2.3.1.4] OK - Guest account renamed to SvcGuest" -Level OK
        } else {
            Write-Log "[2.3.1.4] INFO - Guest account already renamed ($($guest.Name))" -Level OK
        }
    }
} catch { Write-Log "[2.3.1.4] FAILED - Rename guest: $_" -Level ERROR }

# 2.3.7.2 Don't display last signed-in username
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' `
    -Name  'DontDisplayLastUserName' `
    -Value 1 -Type DWord `
    -CISRef '2.3.7.2' -Description 'Do not display last signed-in username'

# ─────────────────────────────────────────────────────────────
# SECTION 2.3.10: NETWORK ACCESS
# ─────────────────────────────────────────────────────────────
Write-Log "--- Section 2.3.10: Network Access ---" -Level INFO

# 2.3.10.1 Allow anonymous SID/Name translation = Disabled
Set-RegistryValue `
    -Path  'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa' `
    -Name  'TurnOffAnonymousBlock' `
    -Value 1 -Type DWord `
    -CISRef '2.3.10.1' -Description 'Block anonymous SID/Name translation'

# 2.3.10.2 Do not allow anonymous enumeration of SAM accounts
Set-RegistryValue `
    -Path  'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa' `
    -Name  'RestrictAnonymousSAM' `
    -Value 1 -Type DWord `
    -CISRef '2.3.10.2' -Description 'Block anonymous SAM account enumeration'

# 2.3.10.3 Do not allow anonymous enumeration of SAM accounts and shares
Set-RegistryValue `
    -Path  'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa' `
    -Name  'RestrictAnonymous' `
    -Value 1 -Type DWord `
    -CISRef '2.3.10.3' -Description 'Block anonymous SAM accounts and shares enumeration'

# 2.3.10.4 Do not allow storage of passwords/credentials for network auth
Set-RegistryValue `
    -Path  'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa' `
    -Name  'DisableDomainCreds' `
    -Value 1 -Type DWord `
    -CISRef '2.3.10.4' -Description 'Prevent credential caching for network auth'

# 2.3.10.5 Let Everyone permissions apply to anonymous users = Disabled
Set-RegistryValue `
    -Path  'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa' `
    -Name  'EveryoneIncludesAnonymous' `
    -Value 0 -Type DWord `
    -CISRef '2.3.10.5' -Description 'Block anonymous privilege escalation via Everyone group'

# 2.3.10.10 Restrict anonymous access to Named Pipes and Shares
Set-RegistryValue `
    -Path  'HKLM:\SYSTEM\CurrentControlSet\Services\LanManServer\Parameters' `
    -Name  'RestrictNullSessAccess' `
    -Value 1 -Type DWord `
    -CISRef '2.3.10.10' -Description 'Restrict anonymous access to Named Pipes and Shares'

# ─────────────────────────────────────────────────────────────
# SECTION 2.3.11: NETWORK SECURITY
# ─────────────────────────────────────────────────────────────
Write-Log "--- Section 2.3.11: Network Security ---" -Level INFO

# 2.3.11.4 Configure encryption types for Kerberos (AES only)
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System\Kerberos\Parameters' `
    -Name  'SupportedEncryptionTypes' `
    -Value 2147483640 -Type DWord `
    -CISRef '2.3.11.4' -Description 'Kerberos: AES128/AES256/Future only (disable DES/RC4)'

# 2.3.11.5 Do not store LAN Manager hash value
Set-RegistryValue `
    -Path  'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa' `
    -Name  'NoLMHash' `
    -Value 1 -Type DWord `
    -CISRef '2.3.11.5' -Description 'Do not store LM hash value'

# 2.3.11.7 LAN Manager authentication level = NTLMv2 only
Set-RegistryValue `
    -Path  'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa' `
    -Name  'LmCompatibilityLevel' `
    -Value 5 -Type DWord `
    -CISRef '2.3.11.7' -Description 'Send NTLMv2 only, refuse LM and NTLM'

# ─────────────────────────────────────────────────────────────
# SECTION 2.3.17: UAC CONTROLS
# ─────────────────────────────────────────────────────────────
Write-Log "--- Section 2.3.17: UAC Controls ---" -Level INFO

# 2.3.17.1 UAC: Admin Approval Mode for Built-in Administrator = Enabled
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' `
    -Name  'FilterAdministratorToken' `
    -Value 1 -Type DWord `
    -CISRef '2.3.17.1' -Description 'UAC Admin Approval Mode for built-in Administrator'

# 2.3.17.2 UAC: Elevation prompt for admins = Prompt for consent on secure desktop
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' `
    -Name  'ConsentPromptBehaviorAdmin' `
    -Value 2 -Type DWord `
    -CISRef '2.3.17.2' -Description 'UAC elevation prompt for admins = Prompt for consent'

# 2.3.17.3 UAC: Elevation prompt for standard users = Automatically deny
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' `
    -Name  'ConsentPromptBehaviorUser' `
    -Value 0 -Type DWord `
    -CISRef '2.3.17.3' -Description 'UAC elevation prompt for standard users = Auto deny'

# 2.3.17.6 UAC: Run all administrators in Admin Approval Mode
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' `
    -Name  'EnableLUA' `
    -Value 1 -Type DWord `
    -CISRef '2.3.17.6' -Description 'UAC: Run all admins in Admin Approval Mode'

# 2.3.17.7 UAC: Switch to secure desktop when prompting for elevation
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' `
    -Name  'PromptOnSecureDesktop' `
    -Value 1 -Type DWord `
    -CISRef '2.3.17.7' -Description 'UAC: Use secure desktop for elevation prompts'

# ─────────────────────────────────────────────────────────────
# SECTION 9: WINDOWS FIREWALL
# ─────────────────────────────────────────────────────────────
Write-Log "--- Section 9: Windows Firewall ---" -Level INFO

# 9.1.1 / 9.2.1 / 9.3.1 Enable all firewall profiles
# 9.1.2 / 9.2.2 / 9.3.2 Block inbound by default
# 9.3.5 Public: Apply local firewall rules = No
try {
    if ($PSCmdlet.ShouldProcess("Windows Firewall", "Configure all profiles")) {
        Set-NetFirewallProfile -Profile Domain  -Enabled True -DefaultInboundAction Block -DefaultOutboundAction Allow
        Set-NetFirewallProfile -Profile Private -Enabled True -DefaultInboundAction Block -DefaultOutboundAction Allow
        Set-NetFirewallProfile -Profile Public  -Enabled True -DefaultInboundAction Block -DefaultOutboundAction Allow
        # Public: disable local rule merge
        Set-NetFirewallProfile -Profile Public -AllowLocalFirewallRules False
        Write-Log "[9.1.1/9.2.1/9.3.1] OK - Firewall enabled on all profiles" -Level OK
        Write-Log "[9.1.2/9.2.2/9.3.2] OK - Default inbound = Block on all profiles" -Level OK
        Write-Log "[9.3.5] OK - Public profile: local firewall rules disabled" -Level OK
    }
} catch { Write-Log "[9.x] FAILED - Firewall configuration: $_" -Level ERROR }

# ─────────────────────────────────────────────────────────────
# SECTION 17: AUDIT POLICY
# ─────────────────────────────────────────────────────────────
Write-Log "--- Section 17: Audit Policy ---" -Level INFO

function Set-AuditPolicy {
    param([string]$Category, [string]$SubCategory, [string]$Setting, [string]$CISRef)
    try {
        if ($PSCmdlet.ShouldProcess($SubCategory, "Set audit: $Setting")) {
            $result = auditpol /set /subcategory:"$SubCategory" /success:$(if($Setting -match 'Success'){'enable'}else{'disable'}) /failure:$(if($Setting -match 'Failure'){'enable'}else{'disable'}) 2>&1
            if ($LASTEXITCODE -eq 0) {
                Write-Log "[$CISRef] OK - Audit $SubCategory = $Setting" -Level OK
            } else {
                Write-Log "[$CISRef] WARN - auditpol: $result" -Level WARN
            }
        }
    } catch { Write-Log "[$CISRef] FAILED - Audit $SubCategory : $_" -Level ERROR }
}

# 17.1.1 Credential Validation
Set-AuditPolicy -SubCategory 'Credential Validation'       -Setting 'Success and Failure' -CISRef '17.1.1'
# 17.2.6 User Account Management
Set-AuditPolicy -SubCategory 'User Account Management'     -Setting 'Success and Failure' -CISRef '17.2.6'
# 17.5.4 Logon
Set-AuditPolicy -SubCategory 'Logon'                       -Setting 'Success and Failure' -CISRef '17.5.4'
# 17.5.6 Special Logon
Set-AuditPolicy -SubCategory 'Special Logon'               -Setting 'Success'             -CISRef '17.5.6'

# ─────────────────────────────────────────────────────────────
# SECTION 18.4: SMBv1 REMOVAL
# ─────────────────────────────────────────────────────────────
Write-Log "--- Section 18.4: SMBv1 Removal ---" -Level INFO

# 18.4.2 Disable SMBv1 Client
try {
    if ($PSCmdlet.ShouldProcess("SMBv1 Client", "Disable")) {
        Set-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Services\MrxSmb10' -Name 'Start' -Value 4 -Type DWord -Force
        Write-Log "[18.4.2] OK - SMBv1 client driver disabled" -Level OK
    }
} catch { Write-Log "[18.4.2] FAILED - SMBv1 client: $_" -Level ERROR }

# 18.4.3 Disable SMBv1 Server
try {
    if ($PSCmdlet.ShouldProcess("SMBv1 Server", "Disable")) {
        Set-SmbServerConfiguration -EnableSMB1Protocol $false -Force
        Write-Log "[18.4.3] OK - SMBv1 server disabled" -Level OK
    }
} catch { Write-Log "[18.4.3] FAILED - SMBv1 server: $_" -Level ERROR }

# ─────────────────────────────────────────────────────────────
# SECTION 18.5 / 18.6 / 18.10: MISC SECURITY SETTINGS
# ─────────────────────────────────────────────────────────────
Write-Log "--- Section 18.5/18.6/18.10: Additional Security ---" -Level INFO

# 18.5.1 MSS: Disable Automatic Logon
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon' `
    -Name  'AutoAdminLogon' `
    -Value 0 -Type DWord `
    -CISRef '18.5.1' -Description 'Disable automatic logon'

# 18.6.8.1 Enable insecure guest logons = Disabled
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft\Windows\LanmanWorkstation' `
    -Name  'AllowInsecureGuestAuth' `
    -Value 0 -Type DWord `
    -CISRef '18.6.8.1' -Description 'Disable insecure guest logons'

# 18.10.57.3.9.4 RDP: Require Network Level Authentication
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services' `
    -Name  'UserAuthentication' `
    -Value 1 -Type DWord `
    -CISRef '18.10.57.3.9.4' -Description 'RDP: Require Network Level Authentication'

# 18.10.57.3.9.5 RDP: Set encryption level = High
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services' `
    -Name  'MinEncryptionLevel' `
    -Value 3 -Type DWord `
    -CISRef '18.10.57.3.9.5' -Description 'RDP: Set client connection encryption level = High'

# 18.10.87.1 Turn on PowerShell Script Block Logging
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft\Windows\PowerShell\ScriptBlockLogging' `
    -Name  'EnableScriptBlockLogging' `
    -Value 1 -Type DWord `
    -CISRef '18.10.87.1' -Description 'Enable PowerShell Script Block Logging'

# 18.10.89.1.1 WinRM Client: Disable Basic authentication
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WinRM\Client' `
    -Name  'AllowBasic' `
    -Value 0 -Type DWord `
    -CISRef '18.10.89.1.1' -Description 'WinRM Client: Disable Basic authentication'

# 18.10.89.2.1 WinRM Service: Disable Basic authentication
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WinRM\Service' `
    -Name  'AllowBasic' `
    -Value 0 -Type DWord `
    -CISRef '18.10.89.2.1' -Description 'WinRM Service: Disable Basic authentication'

# 18.10.93.2.1 Configure Automatic Updates = Enabled (4 = Auto download and schedule install)
Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU' `
    -Name  'AUOptions' `
    -Value 4 -Type DWord `
    -CISRef '18.10.93.2.1' -Description 'Configure Automatic Updates = Enabled'

Set-RegistryValue `
    -Path  'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU' `
    -Name  'NoAutoUpdate' `
    -Value 0 -Type DWord `
    -CISRef '18.10.93.2.1' -Description 'Automatic Updates: NoAutoUpdate = 0'

# ─────────────────────────────────────────────────────────────
# SECTION 2.2: USER RIGHTS - DENY NETWORK/RDP ACCESS
# ─────────────────────────────────────────────────────────────
Write-Log "--- Section 2.2: User Rights Assignment (Deny) ---" -Level INFO

# 2.2.21 Deny access to this computer from network for Guests and Local Accounts
# 2.2.26 Deny RDP logon to Guests and Local Accounts
try {
    if ($PSCmdlet.ShouldProcess("User Rights", "Set deny network/RDP for Guests/Local Accounts")) {
        $tmpCfg = [System.IO.Path]::GetTempFileName() + '.inf'
        $tmpDb  = [System.IO.Path]::GetTempFileName() + '.sdb'
        $infContent = @"
[Unicode]
Unicode=yes
[Version]
signature="`$CHICAGO`$"
Revision=1
[Privilege Rights]
SeDenyNetworkLogonRight = *S-1-5-32-546,*S-1-5-114
SeDenyRemoteInteractiveLogonRight = *S-1-5-32-546,*S-1-5-114
"@
        $infContent | Set-Content -Path $tmpCfg -Encoding Unicode
        secedit /configure /db $tmpDb /cfg $tmpCfg /quiet
        Remove-Item $tmpCfg, $tmpDb -Force -ErrorAction SilentlyContinue
        Write-Log "[2.2.21] OK - Deny network logon: Guests and Local Accounts" -Level OK
        Write-Log "[2.2.26] OK - Deny RDP logon: Guests and Local Accounts" -Level OK
    }
} catch { Write-Log "[2.2.21/2.2.26] FAILED - Deny user rights: $_" -Level ERROR }

# ─────────────────────────────────────────────────────────────
# SUMMARY
# ─────────────────────────────────────────────────────────────
Write-Log "===== CIS P0 Critical Controls - COMPLETE =====" -Level INFO
Write-Log "Log saved to: $LogPath" -Level INFO
Write-Log "NOTE: A reboot is recommended to ensure all settings take full effect." -Level WARN
